﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyChefDemo.Entities
{
    
    public class Recipe : IEntityBase, IAuditable
    {
        public Recipe()
        {
            RecipeIngredients = new List<RecipeIngredient>();
            
           
        }
        public int ID { get; set; }

        public string Name { get; set; }
        public decimal? SellingPrice { get; set; }
        public decimal? DesiredMargin { get; set; }
        public decimal? Ratio { get; set; }

        public string Description { get; set; }

        public decimal? PlateCost { get; set; }
        public decimal? DesiredPlateCost { get; set; }

        public decimal? Difference { get; set; }
        public decimal? ActualMargin { get; set; }
        public decimal? Margin { get; set; }

        public int RestaurantId { get; set; }

        public string Image { get; set; }
        public virtual Restaurant Restaurant { get; set; }

        public virtual ICollection<RecipeIngredient> RecipeIngredients { get; set; }
        
        public bool Status { get; set; }

        public Nullable<DateTime> CreatedDate { get; set; }
        public String CreatedBy { get; set; }
        public Nullable<DateTime> UpdatedDate { get; set; }
        public String UpdatedBy { get; set; }
    }
}
