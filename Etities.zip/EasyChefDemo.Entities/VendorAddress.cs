﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyChefDemo.Entities
{
   

    public class VendorAddress : IEntityBase
    {
        public int ID { get; set; }
        public int VendorId { get; set; }
        public int AddressId { get; set; }
        public virtual Address Address { get; set; }
    }
}
