﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyChefDemo.Entities
{
    public class InventoryItem : IEntityBase, IAuditable
    {
        public InventoryItem()
        {
            RecipeIngredients = new List<RecipeIngredient>();
            InventoryItemLocations = new List<InventoryItemLocation>();
            InventoryItemRestaurants = new List<InventoryItemRestaurant>();
            ApprovedInventories = new List<ApprovedInventory>();
        }


       public int ID { get; set; }

       public string Name { get; set; }
       public string ItemDescription { get; set; }

       public int UnitId { get; set; }
       public virtual Unit Unit { get; set; }

       public decimal ? Quantity { get; set; }
       public decimal? Price { get; set; }

       public Nullable<DateTime> PriceDate { get; set; }  //Current Date show on screen default
       //public int LocationId { get; set; }
       //public virtual Location Location { get; set; }

       public int VendorId { get; set; }
       public virtual Vendor Vendor { get; set; }
       public int CategoryId { get; set; }
       public virtual Category Category { get; set; }

       public int IngredientTypeId { get; set; }
       public IngredientType IngredientType { get; set; }

      // public int RestaurantId { get; set; }
      // public Restaurant Restaurant { get; set; }
       
       public string Image { get; set; }
    
       public virtual ICollection<RecipeIngredient> RecipeIngredients { get; set; }
       public virtual ICollection<InventoryItemLocation> InventoryItemLocations { get; set; }
       public virtual ICollection<InventoryItemRestaurant> InventoryItemRestaurants { get; set; }
       public virtual ICollection<ApprovedInventory> ApprovedInventories { get; set; }
        


        

        //-----


        public bool Status { get; set; }

        public Nullable<DateTime> CreatedDate { get; set; }
        public String CreatedBy { get; set; }
        public Nullable<DateTime> UpdatedDate { get; set; }
        public String UpdatedBy { get; set; }
    }
}
