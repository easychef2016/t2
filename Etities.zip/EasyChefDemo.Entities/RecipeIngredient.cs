﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyChefDemo.Entities
{
   
    public class RecipeIngredient : IEntityBase, IAuditable
    {

        public int ID { get; set; }
        public Guid UniqueKey { get; set; }
        public int InventoryItemId { get; set; }
        public virtual InventoryItem InventoryItem { get; set; }

        public Recipe Recipe { get; set; }
        public int RecipeId { get; set; }

       // public int UnitId { get; set; }
      //  public virtual Unit Unit { get; set; }
       
        public decimal ? Quantity { get; set; }
        public decimal? Price { get; set; }

        public decimal? TotalValue { get; set; }



        public bool Status { get; set; }
        public Nullable<DateTime> CreatedDate { get; set; }
        public String CreatedBy { get; set; }
        public Nullable<DateTime> UpdatedDate { get; set; }
        public String UpdatedBy { get; set; }
    }
}
