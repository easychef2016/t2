﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyChefDemo.Entities
{
   

    public class Unit : IEntityBase, IAuditable
    {
        public Unit()
        {
            IneventoryItems = new List<InventoryItem>();
            //RecipeIngredients = new List<RecipeIngredient>();
        }
        public int ID { get; set; }

        public string Name { get; set; }
        public virtual ICollection<InventoryItem> IneventoryItems { get; set; }
       // public virtual ICollection<RecipeIngredient> RecipeIngredients { get; set; }
        public bool Status { get; set; }

        public Nullable<DateTime> CreatedDate { get; set; }
        public String CreatedBy { get; set; }
        public Nullable<DateTime> UpdatedDate { get; set; }
        public String UpdatedBy { get; set; }
    }
}
