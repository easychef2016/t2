﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyChefDemo.Entities
{
    public class Inventory: IEntityBase, IAuditable
    {
        public Inventory()
        {
            ApprovedInventories = new List<ApprovedInventory>();
            
        }

        public int ID { get; set; }

        public string Name { get; set; }
        public Nullable<DateTime> InventoryDate { get; set; }

        public int? SenttoVendor { get; set; }
        public virtual StatusMaster SenttoVendorStatus { get; set; }
        public Nullable<DateTime> SenttoVendorDate { get; set; }
        public bool? ArchivedStatus { get; set; }
       

        public virtual Restaurant Restaurant { get; set; }
        public int? RestaurantId { get; set; }

        public virtual Vendor Vendor { get; set; }
        public int? VendorId { get; set; }

        public bool Status { get; set; }

        public Nullable<DateTime> CreatedDate { get; set; }
        public String CreatedBy { get; set; }
        public Nullable<DateTime> UpdatedDate { get; set; }
        public String UpdatedBy { get; set; }

        public virtual ICollection<ApprovedInventory> ApprovedInventories { get; set; }
    }
}
