﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyChefDemo.Entities
{
    public class Vendor : IEntityBase, IAuditable
    {
        public Vendor()
        {
            IneventoryItems = new List<InventoryItem>();
            VendorAddresses = new List<VendorAddress>();
            ApprovedInventories = new List<ApprovedInventory>();
            VendorContacts = new List<Contacts>();

        }
        public int ID { get; set; }

        public string Name { get; set; }
        public string Image { get; set; }
        public string SalesAgent { get; set; }
        public bool DotNotCopy { get; set; }

        public string Description { get; set; }
        public virtual ICollection<InventoryItem> IneventoryItems { get; set; }
        public virtual ICollection<VendorAddress> VendorAddresses { get; set; }

      
        public bool Status { get; set; }

        public Nullable<DateTime> CreatedDate { get; set; }
        public String CreatedBy { get; set; }
        public Nullable<DateTime> UpdatedDate { get; set; }
        public String UpdatedBy { get; set; }

        //Added on 082016
        public virtual ICollection<ApprovedInventory> ApprovedInventories { get; set; }


        //Added on 08212016   - START
        public virtual Restaurant restaurant { get; set; }
        public int RestaurantId { get; set; }

        //Added on 08212016 - END


        //Added on 08302016   - START
        public virtual ICollection<Contacts> VendorContacts { get; set; }
    }

}
