﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyChefDemo.Entities
{
    
    public class Address : IEntityBase, IAuditable
    {

        public Address()
        {
           
            RestaurantAddresses = new List<RestaurantAddress>();
            VendorAddresses = new List<VendorAddress>();
            
        }

        public int ID { get; set; }

        
        public string Email { get; set; }
        public string WebsiteURL { get; set; }
        public string PrimaryPhone { get; set; }
        public string SecondaryPhone { get; set; }
        public string Fax { get; set; }


        public string AddressDetails { get; set; }
        public string StreetName { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string Country { get; set; }


        public virtual ICollection<RestaurantAddress> RestaurantAddresses { get; set; }
        public virtual ICollection<VendorAddress> VendorAddresses { get; set; }

        public bool Status { get; set; }

        public Nullable<DateTime> CreatedDate { get; set; }
        public String CreatedBy { get; set; }
        public Nullable<DateTime> UpdatedDate { get; set; }
        public String UpdatedBy { get; set; }
    }
}
