﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyChefDemo.Entities
{
    public class ApprovedInventory : IEntityBase, IAuditable
    {
      
        public int ID { get; set; }
        public Guid UniqueKey { get; set; }
        public int InventoryItemId { get; set; }
        public virtual InventoryItem InventoryItem { get; set; }

        public Inventory Inventory { get; set; }
        public int InventoryId { get; set; }
        public virtual Vendor Vendor { get; set; }
        public int VendorId { get; set; }
      

        public decimal? Quantity { get; set; }
        public decimal? Price { get; set; }

        public decimal? ParValue { get; set; }
        public decimal? MinOrder { get; set; }
        public decimal? Order { get; set; }



        public bool Status { get; set; }
        public Nullable<DateTime> CreatedDate { get; set; }
        public String CreatedBy { get; set; }
        public Nullable<DateTime> UpdatedDate { get; set; }
        public String UpdatedBy { get; set; }


       
    }
}
