﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyChefDemo.Entities
{
    

    public class InventoryItemLocation : IEntityBase
    {
        public int ID { get; set; }
        public int InventoryItemId { get; set; }
        public int LocationId { get; set; }
        public virtual InventoryItem InventoryItem { get; set; }
    }
}
