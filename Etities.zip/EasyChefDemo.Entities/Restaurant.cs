﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyChefDemo.Entities
{
    
    public class Restaurant : IEntityBase, IAuditable
    {
        public Restaurant()
        {
            Users = new List<User>();
          //  IneventoryItems = new List<InventoryItem>();
            RestaurantAddresses = new List<RestaurantAddress>();
            UserRestaurants = new List<UserRestaurant>();
            Recipes = new List<Recipe>();
            InventoryItemRestaurants = new List<InventoryItemRestaurant>();

            //Added on 08212016
            Vendors = new List<Vendor>();
            //Added on 08302016
            ContactsLists = new List<Contacts>();
            //Added on 01112017
            SubscriptionLists = new List<Subscription>();
        }
        public int ID { get; set; }

        public string Name { get; set; }

        public string Image { get; set; }

        public string Description { get; set; }

        public bool GlobalBar { get; set; }
        public bool AutoOrder { get; set; }
        public bool NoQty { get; set; }

       // public virtual ICollection<InventoryItem> IneventoryItems { get; set; }

        public virtual ICollection<RestaurantAddress> RestaurantAddresses { get; set; }
        public virtual ICollection<UserRestaurant> UserRestaurants { get; set; }
        public virtual ICollection<Recipe> Recipes { get; set; }

        public virtual ICollection<InventoryItemRestaurant> InventoryItemRestaurants { get; set; }
        public virtual ICollection<User> Users { get; set; }



        public virtual ICollection<Vendor> Vendors { get; set; }
        //Added on 08/30/2016
        public virtual ICollection<Contacts> ContactsLists { get; set; }


        //Added on 01/11/2017
        public virtual ICollection<Subscription> SubscriptionLists { get; set; }


        public bool Status { get; set; }

        public Nullable<DateTime> CreatedDate { get; set; }
        public String CreatedBy { get; set; }
        public Nullable<DateTime> UpdatedDate { get; set; }
        public String UpdatedBy { get; set; }
    }
}
