﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyChefDemo.Entities
{
   
    public class RestaurantAddress : IEntityBase
    {
        public int ID { get; set; }
        public int RestaurantId { get; set; }
        public int AddressId { get; set; }
        public virtual Address Address { get; set; }
        public virtual Restaurant Restaurant { get; set; }
    }
}
