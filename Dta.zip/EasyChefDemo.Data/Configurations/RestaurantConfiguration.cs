﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.Entity.ModelConfiguration;
using EasyChefDemo.Entities;

namespace EasyChefDemo.Data.Configurations
{

    public class RestaurantConfiguration:EntityBaseConfiguration<Restaurant>
    {
        public RestaurantConfiguration()
        {
            Property(r => r.Name).IsRequired().HasMaxLength(50);
            Property(r => r.AutoOrder).IsOptional();
            Property(r => r.GlobalBar).IsOptional();
            Property(r => r.NoQty).IsOptional();
            Property(r => r.Description).IsOptional().HasMaxLength(150); ;
            Property(r => r.Status).IsOptional();
            Property(r => r.CreatedBy).IsOptional().HasMaxLength(50);
            Property(r => r.CreatedDate).IsOptional();
            Property(r => r.UpdatedBy).IsOptional().HasMaxLength(50);
            Property(r => r.UpdatedDate).IsOptional();

            //Relationships
            HasMany(r => r.RestaurantAddresses).WithRequired().HasForeignKey(ra => ra.RestaurantId);
           //Relationships
            HasMany(r => r.UserRestaurants).WithRequired().HasForeignKey(ur => ur.RestaurantId);

            //Added 08212016
            HasMany(r => r.Vendors).WithRequired().HasForeignKey(ur => ur.RestaurantId);

            //Added 08302016

            HasMany(v => v.ContactsLists).WithOptional().HasForeignKey(cl => cl.RestaurantId);

            //Added 08302016

            HasMany(r => r.SubscriptionLists).WithOptional().HasForeignKey(subscriptions => subscriptions.RestaurantId);

        }
    }
}

