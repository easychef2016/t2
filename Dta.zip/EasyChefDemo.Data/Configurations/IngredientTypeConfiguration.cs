﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.Data.Entity.ModelConfiguration;
using EasyChefDemo.Entities;

namespace EasyChefDemo.Data.Configurations
{

    public class IngredientTypeConfiguration : EntityBaseConfiguration<IngredientType>
    {
        public IngredientTypeConfiguration()
        {
            Property(it => it.Name).IsRequired().HasMaxLength(50);


            Property(it => it.Status).IsOptional();
            Property(it => it.CreatedBy).IsOptional().HasMaxLength(50);
            Property(it => it.CreatedDate).IsOptional();
            Property(it => it.UpdatedBy).IsOptional().HasMaxLength(50);
            Property(it => it.UpdatedDate).IsOptional();


        }
    }
}
