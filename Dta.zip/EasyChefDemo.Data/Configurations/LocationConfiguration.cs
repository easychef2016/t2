﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.Entity.ModelConfiguration;
using EasyChefDemo.Entities;

namespace EasyChefDemo.Data.Configurations
{
   
    public class LocationConfiguration : EntityBaseConfiguration<Location>
    {
        public LocationConfiguration()
        {
            Property(l => l.Name).IsRequired().HasMaxLength(50);


            Property(l => l.Status).IsOptional();
            Property(l => l.CreatedBy).IsOptional().HasMaxLength(50);
            Property(l => l.CreatedDate).IsOptional();
            Property(l => l.UpdatedBy).IsOptional().HasMaxLength(50);
            Property(l => l.UpdatedDate).IsOptional();
        }
    }
}
