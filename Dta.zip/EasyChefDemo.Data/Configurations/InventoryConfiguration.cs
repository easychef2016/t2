﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.Entity.ModelConfiguration;
using EasyChefDemo.Entities;

namespace EasyChefDemo.Data.Configurations
{
    public class InventoryConfiguration :EntityBaseConfiguration<Inventory>
    {
        public InventoryConfiguration()
        {
            Property(i => i.Name).IsRequired().HasMaxLength(50);

            Property(i => i.InventoryDate).IsRequired();


            Property(i => i.SenttoVendor).IsOptional();
            Property(i => i.SenttoVendorDate).IsOptional();
            Property(i => i.ArchivedStatus).IsOptional();
            Property(i => i.RestaurantId).IsOptional();
            Property(i => i.VendorId).IsOptional(); 
           


            Property(i => i.Status).IsOptional();
            Property(i => i.CreatedBy).IsOptional().HasMaxLength(50);
            Property(i => i.CreatedDate).IsOptional();
            Property(i => i.UpdatedBy).IsOptional().HasMaxLength(50);
            Property(i => i.UpdatedDate).IsOptional();

            HasMany(i => i.ApprovedInventories).WithRequired().HasForeignKey(ap => ap.InventoryId);
        }
    }
}
