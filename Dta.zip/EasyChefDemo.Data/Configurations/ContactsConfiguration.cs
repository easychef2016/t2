﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.Data.Entity.ModelConfiguration;
using EasyChefDemo.Entities;

namespace EasyChefDemo.Data.Configurations
{
    
    public class ContactsConfiguration : EntityBaseConfiguration<Contacts>
    {

        public ContactsConfiguration()
        {
            Property(c => c.Email).IsOptional();
            Property(c => c.WebsiteURL).IsOptional();
            Property(c => c.CellPhone).IsOptional().HasMaxLength(50);
            Property(c => c.WorkPhone).IsOptional().HasMaxLength(50);
            Property(c => c.Fax).IsOptional().HasMaxLength(50);

            Property(c => c.RestaurantId).IsOptional();
            Property(c => c.UserId).IsOptional();
            Property(c => c.VendorId).IsOptional();



            //Aduit Details
            Property(c => c.Status).IsOptional();
            Property(c => c.CreatedBy).IsOptional().HasMaxLength(50);
            Property(c => c.CreatedDate).IsOptional();
            Property(c => c.UpdatedBy).IsOptional().HasMaxLength(50);
            Property(c => c.UpdatedDate).IsOptional();

         }
    }
}
