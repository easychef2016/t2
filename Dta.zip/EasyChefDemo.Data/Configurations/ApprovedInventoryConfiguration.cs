﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.Entity.ModelConfiguration;
using EasyChefDemo.Entities;

namespace EasyChefDemo.Data.Configurations
{
    public class ApprovedInventoryConfiguration : EntityBaseConfiguration<ApprovedInventory>
    {
        public ApprovedInventoryConfiguration()
        {

            Property(ai => ai.UniqueKey).IsRequired();

            Property(ai => ai.InventoryItemId).IsRequired();
            Property(ai => ai.InventoryId).IsRequired();
            Property(ai => ai.VendorId).IsRequired();

            //relationship  
            // HasRequired(ri => ri.Unit).WithMany(u =>u.RecipeIngredients).HasForeignKey(ri => ri.UnitId).WillCascadeOnDelete(false);  
            // Property(ri => ri.UnitId).IsOptional();

            //HasRequired(ri => ri.Unit).WithOptional(u => u.RecipeIngredients).WillCascadeOnDelete();

            Property(ai => ai.Quantity).IsOptional();
            Property(ai => ai.Price).IsOptional();
            Property(ai => ai.ParValue).IsOptional();
            Property(ai => ai.MinOrder).IsOptional();
            Property(ai => ai.Order).IsOptional();

            Property(ai => ai.Status).IsOptional();
            Property(ai => ai.CreatedBy).IsOptional().HasMaxLength(50);
            Property(ai => ai.CreatedDate).IsOptional();
            Property(ai => ai.UpdatedBy).IsOptional().HasMaxLength(50);
            Property(ai => ai.UpdatedDate).IsOptional();
        }
    }
}
