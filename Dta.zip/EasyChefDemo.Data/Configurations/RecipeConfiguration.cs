﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.Entity.ModelConfiguration;
using EasyChefDemo.Entities;

namespace EasyChefDemo.Data.Configurations
{
    public class RecipeConfiguration : EntityBaseConfiguration<Recipe>
    {
        public RecipeConfiguration()
        {
            Property(r => r.Name).IsRequired().HasMaxLength(50);

            Property(r => r.SellingPrice).IsRequired().HasPrecision(12, 2);
            Property(r => r.DesiredMargin).IsRequired().HasPrecision(12, 2);

            Property(r => r.Ratio).IsOptional().HasPrecision(12, 2);
            Property(r => r.Description).IsOptional().HasMaxLength(150);
            Property(r => r.PlateCost).IsOptional().HasPrecision(12, 2);
            Property(r => r.DesiredPlateCost).IsOptional().HasPrecision(12, 2);
            Property(r => r.Difference).IsOptional().HasPrecision(12, 2);
            Property(r => r.ActualMargin).IsOptional().HasPrecision(12, 2);
            Property(r => r.Margin).IsOptional().HasPrecision(12, 2);
            Property(r => r.RestaurantId).IsOptional();
            Property(r => r.Image).IsOptional();
           

         
            Property(r => r.Status).IsOptional();
            Property(r => r.CreatedBy).IsOptional().HasMaxLength(50);
            Property(r => r.CreatedDate).IsOptional();
            Property(r => r.UpdatedBy).IsOptional().HasMaxLength(50);
            Property(r => r.UpdatedDate).IsOptional();

            HasMany(r => r.RecipeIngredients).WithRequired().HasForeignKey(ri => ri.RecipeId);
        }
    }
}
