﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.Entity.ModelConfiguration;
using EasyChefDemo.Entities;

namespace EasyChefDemo.Data.Configurations
{
   
    public class VendorConfiguration : EntityBaseConfiguration<Vendor>
    {
        public VendorConfiguration()
        {
            Property(v => v.Name).IsRequired().HasMaxLength(50);
            Property(v => v.SalesAgent).IsRequired().HasMaxLength(100);
            Property(v => v.DotNotCopy).IsOptional();
            Property(v => v.Description).IsOptional().HasMaxLength(100);
            
            //Added 08212016
            Property(v => v.RestaurantId).IsRequired();

            Property(v => v.Status).IsOptional();
            Property(v => v.CreatedBy).IsOptional().HasMaxLength(50);
            Property(v => v.CreatedDate).IsOptional();
            Property(v => v.UpdatedBy).IsOptional().HasMaxLength(50);
            Property(v => v.UpdatedDate).IsOptional();

            //Relationships
            HasMany(v => v.VendorAddresses).WithRequired().HasForeignKey(va => va.VendorId);


            //Added 08152016
            HasMany(v => v.ApprovedInventories).WithRequired().HasForeignKey(va => va.VendorId);

            //Added 08292016

            HasMany(v => v.IneventoryItems).WithRequired().HasForeignKey(va => va.VendorId);

            //Added 08302016

            HasMany(v => v.VendorContacts).WithOptional().HasForeignKey(cl => cl.VendorId);

          



   
            

        }
    }
}
