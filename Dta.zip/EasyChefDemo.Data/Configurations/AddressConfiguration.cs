﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.Data.Entity.ModelConfiguration;
using EasyChefDemo.Entities;

namespace EasyChefDemo.Data.Configurations
{
   

    public class AddressConfiguration : EntityBaseConfiguration<Address>
    {
        public AddressConfiguration()
        {
            Property(a => a.Email).IsRequired();
           // Property(a => a.WebsiteURL).IsRequired();
            Property(a => a.WebsiteURL).IsOptional();
            Property(a => a.PrimaryPhone).IsOptional().HasMaxLength(50);
            Property(a => a.SecondaryPhone).IsOptional().HasMaxLength(50);
            Property(a => a.Fax).IsOptional().HasMaxLength(50);
            Property(a => a.AddressDetails).IsOptional().HasMaxLength(100);
            Property(a => a.StreetName).IsOptional().HasMaxLength(100);
            Property(a => a.City).IsOptional().HasMaxLength(100);
            Property(a => a.State).IsOptional().HasMaxLength(100);
            Property(a => a.Zip).IsOptional().HasMaxLength(100);
            Property(a => a.Country).IsOptional().HasMaxLength(100);

            
            //Aduit Details
            Property(a => a.Status).IsOptional();
            Property(a => a.CreatedBy).IsOptional().HasMaxLength(50);
            Property(a => a.CreatedDate).IsOptional();
            Property(a => a.UpdatedBy).IsOptional().HasMaxLength(50);
            Property(a => a.UpdatedDate).IsOptional();

            //Relationships
            HasMany(a=> a.RestaurantAddresses).WithRequired().HasForeignKey(ra => ra.AddressId);
            HasMany(a => a.VendorAddresses).WithRequired().HasForeignKey(ra => ra.AddressId);


          
            
        }
    }
}
