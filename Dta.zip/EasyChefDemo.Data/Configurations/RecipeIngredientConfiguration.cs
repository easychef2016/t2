﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.Entity.ModelConfiguration;
using EasyChefDemo.Entities;


namespace EasyChefDemo.Data.Configurations
{
   

    public class RecipeIngredientConfiguration : EntityBaseConfiguration<RecipeIngredient>
    {
        public RecipeIngredientConfiguration()
        {

            //HasKey(ri => new {ri.RecipeId, ri.InventoryItemId});

            Property(ri => ri.UniqueKey).IsRequired();

            Property(ri => ri.RecipeId).IsRequired();
            Property(ri => ri.InventoryItemId).IsRequired();

            //relationship  
           // HasRequired(ri => ri.Unit).WithMany(u =>u.RecipeIngredients).HasForeignKey(ri => ri.UnitId).WillCascadeOnDelete(false);  
           // Property(ri => ri.UnitId).IsOptional();
            
            //HasRequired(ri => ri.Unit).WithOptional(u => u.RecipeIngredients).WillCascadeOnDelete();
            
            Property(ri => ri.Quantity).IsOptional();
            Property(ri => ri.Price).IsOptional();
            Property(ri => ri.TotalValue).IsOptional();

            Property(ri => ri.Status).IsOptional();
            Property(ri => ri.CreatedBy).IsOptional().HasMaxLength(50);
            Property(ri => ri.CreatedDate).IsOptional();
            Property(ri => ri.UpdatedBy).IsOptional().HasMaxLength(50);
            Property(ri => ri.UpdatedDate).IsOptional();
        }
    }
}
