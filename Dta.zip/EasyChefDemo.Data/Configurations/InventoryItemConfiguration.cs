﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.Entity.ModelConfiguration;
using EasyChefDemo.Entities;

namespace EasyChefDemo.Data.Configurations
{
    
    public class InventoryItemConfiguration : EntityBaseConfiguration<InventoryItem>
    {
        public InventoryItemConfiguration()
        {
            Property(i => i.Name).IsRequired().HasMaxLength(50);

            Property(i => i.ItemDescription).IsRequired().HasMaxLength(100);
            Property(i => i.UnitId).IsRequired();
           // HasRequired(i => i.Unit).WithMany(u =>u.IneventoryItems).HasForeignKey(it => it.UnitId);

            Property(i => i.Quantity).IsOptional().HasPrecision(12, 2);
            Property(i => i.Price).IsOptional().HasPrecision(12, 2);
            Property(i => i.PriceDate).IsOptional();
            //Property(i => i.LocationId).IsRequired();
            Property(i => i.VendorId).IsRequired();
           // Property(i => i.CategoryId).IsRequired();
            HasRequired(i => i.Category).WithMany(c => c.IneventoryItems).HasForeignKey(it => it.CategoryId);

            Property(i => i.IngredientTypeId).IsRequired();
            //Property(i => i.RestaurantId).IsRequired();
            
            Property(i => i.Image).IsOptional();


            Property(i => i.Status).IsOptional();
            Property(i => i.CreatedBy).IsOptional().HasMaxLength(50);
            Property(i => i.CreatedDate).IsOptional();
            Property(i => i.UpdatedBy).IsOptional().HasMaxLength(50);
            Property(i => i.UpdatedDate).IsOptional();

            HasMany(i => i.RecipeIngredients).WithRequired().HasForeignKey(ri => ri.InventoryItemId);
            HasMany(i => i.ApprovedInventories).WithRequired().HasForeignKey(ap => ap.InventoryItemId);
        }
    }
}
