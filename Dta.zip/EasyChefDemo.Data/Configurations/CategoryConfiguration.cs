﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.Data.Entity.ModelConfiguration;
using EasyChefDemo.Entities;


namespace EasyChefDemo.Data.Configurations
{
    public class CategoryConfiguration:EntityBaseConfiguration<Category>
    {
        public CategoryConfiguration()
        {
            Property(c => c.Name).IsRequired().HasMaxLength(50);


            Property(c => c.Status).IsOptional();
            Property(c => c.CreatedBy).IsOptional().HasMaxLength(50);
            Property(c => c.CreatedDate).IsOptional();
            Property(c => c.UpdatedBy).IsOptional().HasMaxLength(50);
            Property(c => c.UpdatedDate).IsOptional();

            HasMany(c => c.IneventoryItems).WithRequired(it => it.Category).HasForeignKey(it => it.CategoryId);
        }
    }
}
