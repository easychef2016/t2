﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.Data.Entity.ModelConfiguration;
using EasyChefDemo.Entities;


namespace EasyChefDemo.Data.Configurations
{
    public class StatusMasterConfiguration : EntityBaseConfiguration<StatusMaster>
    {
        public StatusMasterConfiguration()
        {
            Property(sm => sm.Status).IsOptional();
            Property(sm => sm.Description).IsOptional().HasMaxLength(200);
           
                      
            //Aduit Details
            Property(sm => sm.Status).IsOptional();
            Property(sm => sm.CreatedBy).IsOptional().HasMaxLength(50);
            Property(sm => sm.CreatedDate).IsOptional();
            Property(sm => sm.UpdatedBy).IsOptional().HasMaxLength(50);
            Property(sm => sm.UpdatedDate).IsOptional();


          


          
            
        }
    }
}
