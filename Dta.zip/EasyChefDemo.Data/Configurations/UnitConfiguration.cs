﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.Entity.ModelConfiguration;
using EasyChefDemo.Entities;

namespace EasyChefDemo.Data.Configurations
{
    

    public class UnitConfiguration : EntityBaseConfiguration<Unit>
    {
        public UnitConfiguration()
        {
            Property(u => u.Name).IsRequired().HasMaxLength(50);


            Property(u => u.Status).IsOptional();
            Property(u => u.CreatedBy).IsOptional().HasMaxLength(50);
            Property(u => u.CreatedDate).IsOptional();
            Property(u => u.UpdatedBy).IsOptional().HasMaxLength(50);
            Property(u => u.UpdatedDate).IsOptional();

            //HasMany(u => u.RecipeIngredients).WithRequired().HasForeignKey(ri => ri.UnitId);

           // HasMany(u => u.IneventoryItems).WithRequired(it => it.Unit).HasForeignKey(it => it.UnitId);
        }
    }
}
