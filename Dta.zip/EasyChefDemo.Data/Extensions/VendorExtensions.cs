﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using EasyChefDemo.Entities;
using EasyChefDemo.Data.Repositories;

namespace EasyChefDemo.Data.Extensions
{
     public static class VendorExtensions
    {
        public static Vendor GetSingleByVendorname(this IEntityBaseRepository<Vendor> vendorRepository, string vendorname)
        {
            return vendorRepository.GetAll().FirstOrDefault(x => x.Name == vendorname);
        }
    }
}
