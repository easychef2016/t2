﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyChefDemo.Data.Infrastructure
{
    public class DbFactory : Disposable, IDbFactory
    {
        EasyChefDemoContext dbContext;

        public EasyChefDemoContext Init()
        {
            return dbContext ?? (dbContext = new EasyChefDemoContext());
        }

        protected override void DisposeCore()
        {
            if (dbContext != null)
                dbContext.Dispose();
        }
    }
}
