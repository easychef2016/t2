﻿/// <reference path="../layout/sideBarold.html" />
(function (app) {
    'use strict';

    app.controller('rootCtrl', rootCtrl);

    //rootCtrl.$inject = ['$scope', '$location', 'membershipService', '$rootScope', '$mdSidenav', '$state'];
    //function rootCtrl($scope, $location, membershipService, $rootScope, $mdSidenav, $state) {
    rootCtrl.$inject = ['$scope', '$location', 'membershipService', '$rootScope', '$cookies', '$state'];
    function rootCtrl($scope, $location, membershipService, $rootScope,$cookies,$state) {
      
        $scope.userData = {};
        $scope.userData.displayUserInfo = displayUserInfo;
        $scope.logout = logout;
        $scope.gotoProfile = gotoProfile;
        // $rootScope.repository = {
        //      loggedUser: {
        //          username:'',
        //          authdata: ''
        //       }
        //   };

        // $rootScope.repository = $cookies.getObject('repository') || {};
        // debugger;
        //if ($rootScope.repository.loggedUser) {
        //    $http.defaults.headers.common['Authorization'] = $rootScope.repository.loggedUser.authdata;

        //}



        function displayUserInfo() {
            $scope.userData.isUserLoggedIn = membershipService.isUserLoggedIn();

            if ($scope.userData.isUserLoggedIn) {
                $scope.username = $rootScope.repository.loggedUser.username;
            }
        }

        function logout() {
           
            membershipService.removeCredentials();
            // $location.path('#/');
            $location.path('/');
            $scope.userData.displayUserInfo();
        }
        function gotoProfile() {         
            $state.go("Management.Profile");
        }

        

        function login() {           
            $state.go("login");
        }

        $scope.userData.displayUserInfo();




        //Added as part of Angular Material

      //  $scope.menuItems = [
      //{ name: 'home', path: 'home' },
      //{ name: 'login', path: 'login' },
      //{ name: 'register', path: 'register' },
      //{ name: 'Management', path: 'Management' },
      //{ name: 'Management.recipies', path: 'Management.recipies' },
      //{ name: 'grid list', path: 'gridList' },
      //{ name: 'input', path: 'input' },
      //{ name: 'progress circular', path: 'progressCircular' },
      //{ name: 'progress linear', path: 'progressLinear' },
      //{ name: 'toast', path: 'toast' },
      //{ name: 'whiteframe', path: 'whiteframe' },
      //  ];

      //  $scope.title = 'home';

      //  $scope.go = function (path, title) {
      //      $state.go(path);
      //      $scope.title = title;
      //  }

        //$scope.toggleLeft = function () {
        //    $mdSidenav('left')
        //          .toggle();
        //}

        //$scope.menuIcon = 'menu';
        //$scope.menuToggle = function () {
        //    if ($scope.menuIcon == 'menu') {
        //        $mdSidenav('left')
        //          .open();
        //        $scope.menuIcon = 'arrow_back';
        //    }
        //    else {
        //        $mdSidenav('left')
        //          .close();
        //        $scope.menuIcon = 'menu';
        //    }
        //}

        // controls sidebar expand/close
        //controll sidebar open & close in mobile and normal view
        $scope.sideBar = function (value) {
           // alert("sidebar");
            if ($(window).width() <= 767) {
                if ($("body").hasClass('sidebar-open'))
                    $("body").removeClass('sidebar-open');
                else
                    $("body").addClass('sidebar-open');
            }
            else {
                if (value == 1) {
                    if ($("body").hasClass('sidebar-collapse'))
                        $("body").removeClass('sidebar-collapse');
                    else
                        $("body").addClass('sidebar-collapse');
                }
            }
        };
            
          

       


        $scope.collapseVar = 0;
        $scope.check = function (x) {

            if (x == $scope.collapseVar)
                $scope.collapseVar = 0;
            else
                $scope.collapseVar = x;
        };

        $scope.collapseVar1 = 0;
        $scope.check1 = function (x) {

            if (x == $scope.collapseVar1)
                $scope.collapseVar1 = 0;
            else
                $scope.collapseVar1 = x;
        };

        $scope.collapseVar2 = 0;
        $scope.check2 = function (x) {

            if (x == $scope.collapseVar2)
                $scope.collapseVar2 = 0;
            else
                $scope.collapseVar2 = x;
        };

        $scope.collapseVar3 = 0;
        $scope.check3 = function (x) {

            if (x == $scope.collapseVar3)
                $scope.collapseVar3 = 0;
            else
                $scope.collapseVar3 = x;
        };

        $scope.collapseVar4 = 0;
        $scope.check4 = function (x) {

            if (x == $scope.collapseVar4)
                $scope.collapseVar4 = 0;
            else
                $scope.collapseVar4 = x;
        };


        $scope.collapseVar5 = 0;
        $scope.check5 = function (x) {

            if (x == $scope.collapseVar5)
                $scope.collapseVar5 = 0;
            else
                $scope.collapseVar5 = x;
        };


    }

})(angular.module('easychefdemo'));