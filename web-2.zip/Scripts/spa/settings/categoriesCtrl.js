﻿(function (app) {
    'use strict';

    app.controller('categoriesCtrl', categoriesCtrl);

    categoriesCtrl.$inject = ['$scope', 'apiService', 'notificationService'];

    function categoriesCtrl($scope, apiService, notificationService) {
        
        // $scope.pageClass = 'page-home';
        $scope.loadingcategories = true;
        $scope.isReadOnly = true;

        $scope.latestcategories = [];
        $scope.selectedcategory = {};


        $scope.loadData = loadData;

        //below var declared for edit/update/cancel
        $scope.newCategories = [];
        $scope.editing = false;

        $scope.getStatusColor = getStatusColor;
        $scope.getStatustext = getStatustext;

        function getStatusColor(status) {
           // alert("test");
            if (status == 'True' || status== true)
                return 'green'
            else {
                return 'red';
            }
        }

        function getStatus(status)
        {
           
            if (status == 'True' || status == true)
                return 'true'
            else {
                return 'false';
            }

        }

        function getStatustext(status) {
            // alert("test");
            if (status == 'True' || status == true)
                return 'Active';
            else {
                return 'In Active';
            }
        }

        

        function loadData() {
            apiService.get('/api/categories/latest', null,
                       categoriesLoadCompleted,
                        categoriesLoadFailed);
          
        }

        function categoriesLoadCompleted(result) {
          
            $scope.latestcategories = result.data;
            $scope.loadingcategories = false;
        }

        function categoriesLoadFailed(response) {
          
            notificationService.displayError(response.data);
        }

         $scope.editCategory = function (category) {
             //alert(category.Status);
           $scope.editing = $scope.latestcategories.indexOf(category);
           $scope.newCategories[$scope.editing] = angular.copy(category);
        

        };

        $scope.updateCategory = function (category) {
            //alert(category.ID);
            //alert(category.Name);
            $scope.selectedcategory = angular.copy(category);
            apiService.post('/api/categories/update', category,
               updateCategoryItemSucceded,
               updateCategoryItemSFailed);
        };


        $scope.cancel = function (index) {

                //if ($scope.editing !== false) {
                $scope.latestcategories[$scope.editing] = $scope.newCategories[index];
                $scope.editing = false;
               //}
        };


       function updateCategoryItemSucceded(response) {
           console.log(response);
           notificationService.displaySuccess($scope.selectedcategory.Name + ' has been updated');
           loadData();
           
       }

       function updateCategoryItemSFailed(response) {
           notificationService.displayError(response);
       }
                      

       

        loadData();
    }

})(angular.module('easychefdemo'));