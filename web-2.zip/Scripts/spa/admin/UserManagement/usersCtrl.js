﻿(function (app) {
    'use strict';

    app.controller('usersCtrl', usersCtrl);

    usersCtrl.$inject = ['$scope', 'apiService', 'notificationService', '$rootScope'];

    function usersCtrl($scope, apiService, notificationService, $rootScope) {

        // $scope.pageClass = 'page-home';
        $scope.loadingusers= true;
        $scope.isReadOnly = true;

        $scope.latestusers = [];

        $scope.loadData = loadData;
        $scope.loadUserdata = loadUserdata;




        function loadUserdata() {

            if ($rootScope.repository.loggedUser) {
                $scope.filterUsername = $rootScope.repository.loggedUser.username;

            }
        }
       

        $scope.getStatusColor = getStatusColor;
        $scope.getStatustext = getStatustext;

        function getStatusColor(status) {
            // alert("test");
            if (status == 'True' || status == true)
                return 'green'
            else {
                return 'red';
            }
        }

        function getStatus(status) {
            if (status == 'True' || status == true)
                return 'true'
            else {
                return 'false';
            }

        }

        function getStatustext(status) {           
            if (status == 'True' || status == true)
                return 'Active';
            else {
                return 'In Active';
            }
        }



        function loadData() {
            var config = {
                params: {

                    filter: $scope.filterUsername
                }
            };


            apiService.get('/api/Users/latest', config,
                       usersLoadCompleted,
                        usersLoadFailed);

        }

        function usersLoadCompleted(result) {

            $scope.latestusers = result.data;
            $scope.loadingusers = false;
        }

        function usersLoadFailed(response) {

            notificationService.displayError(response.data);
        }

      


        loadUserdata();
        loadData();
    }

})(angular.module('easychefdemo'));