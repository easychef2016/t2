﻿(function (app) {
    'use strict';

    app.controller('recipiesCtrl', recipiesCtrl);

    recipiesCtrl.$inject = ['$scope','apiService', 'notificationService'];

    function recipiesCtrl($scope, apiService, notificationService) {
      //  alert("recipie");
       // $scope.pageClass = 'page-home';
        $scope.loadingRecipies = true;
        //$scope.loadingGenres = true;
        $scope.isReadOnly = true;

        $scope.latestRecipies = [];
        $scope.loadData = loadData;


       
        function loadData() {
            apiService.get('/api/recipies/latest', null,
                       recipiesLoadCompleted,
                        recipiesLoadFailed);
           // alert("load");
            //apiService.get("/api/genres/", null,
            //    genresLoadCompleted,
            //    genresLoadFailed);
        }

        function recipiesLoadCompleted(result) {
            //alert("completed");
          
            $scope.latestRecipies = result.data;
            //alert($scope.latestRecipies);
            $scope.loadingRecipies = false;
        }

        //function genresLoadFailed(response) {
        //    notificationService.displayError(response.data);
        //}

        function recipiesLoadFailed(response) {
           // alert("error");
          //  debugger;
         //   alert(response.data);
            notificationService.displayError(response.data);
        }

        //function genresLoadCompleted(result) {
        //    var genres = result.data;
        //    Morris.Bar({
        //        element: "genres-bar",
        //        data: genres,
        //        xkey: "Name",
        //        ykeys: ["NumberOfMovies"],
        //        labels: ["Number Of Movies"],
        //        barRatio: 0.4,
        //        xLabelAngle: 55,
        //        hideHover: "auto",
        //        resize: 'true'
        //    });
            //.on('click', function (i, row) {
            //    $location.path('/genres/' + row.ID);
            //    $scope.$apply();
            //});

          // $scope.loadingGenres = false;
        //}

        loadData();
    }

})(angular.module('easychefdemo'));