﻿(function (app) {
    'use strict';

    app.controller('recipeAddCtrl', recipeAddCtrl);

    recipeAddCtrl.$inject = ['$scope', '$location', '$timeout', 'apiService', 'notificationService'];

    function recipeAddCtrl($scope, $location, $timeout, apiService, notificationService) {

        //alert("recipe add");
        //$scope.pageClass = 'page-movies';
        //$scope.recipe = { CategoryId: 1, UnitId: 1 };

        $scope.categories = [];
        $scope.units = [];

        $scope.isReadOnly = false;
        $scope.AddRecipe = AddRecipe;
        $scope.prepareFiles = prepareFiles;
        var recipeImage = null;
       
        $scope.addrecipeIngredients = addrecipeIngredients;
        $scope.DeleterecipeIngredients = DeleterecipeIngredients;
        //$scope.recipe.InventoryItems = [];
        $scope.loadingredients = loadingredients;
        $scope.latestingredients = [];

        //---TYPEAHEAD SEARCH - STARTS 
        $scope.selectInventoryItem = selectInventoryItem;
        $scope.selectionChanged = selectionChanged;
        $scope.selectedtInventoryItem = -1;
        $scope.isEnabled = false;

        function selectInventoryItem($item) {
            if ($item) {
                $scope.recipe.recipeIngredients[this.$parent.$index].ID = $item.originalObject.ID;
                $scope.isEnabled = true;
            }
            else {
                $scope.selectedtInventoryItem = -1;
                $scope.isEnabled = false;
            }
        }

        function selectionChanged($item) {
        }


        ////TYPEAHEAD SEARCH ENDS....

        $scope.recipe = {
         
            recipeIngredients: [{
                ID: '',
                UnitId: null,
                Units: '',
                Price: '',
                TotalValue: ''
            }]
        };


    


        function loadingredients() {
            apiService.get('/api/inventoryitems/latest', null,
                       ingredientsLoadCompleted,
                        ingredientsLoadFailed);
          
        }

        function ingredientsLoadCompleted(result) {
            $scope.latestingredients = result.data;
           // $scope.loadinginventoryItems = false;
        }

        function ingredientsLoadFailed(response) {
            notificationService.displayError(response.data);
        }
          
        function DeleterecipeIngredients(index) {
           
            $scope.recipe.recipeIngredients.splice(index, 1);
        }

       
        function addrecipeIngredients() {

            $scope.recipe.recipeIngredients.push(
            {
                'ID': '',
                'UnitId': '',
                'Units': '',
                'Price': '',
                'TotalValue': ''

            });
        }

        function loadcategories() {
            apiService.get('/api/categories/latest', null,
            categoriesLoadCompleted,
            categoriesLoadFailed);
        }

        function categoriesLoadCompleted(response) {
            $scope.categories = response.data;
        }

        function categoriesLoadFailed(response) {
           
            notificationService.displayError(response.data);
        }


        function loadunits() {
            apiService.get('/api/units/latest', null,
            unitsLoadCompleted,
            unitsLoadFailed);
        }

        function unitsLoadCompleted(response) {
            $scope.units = response.data;
        }

        function unitsLoadFailed(response) {
            notificationService.displayError(response.data);
        }





        function AddRecipe() {
            AddRecipeModel();
        }

        function AddRecipeModel() {
            //alert("Recipe");
            $scope.submitted = true;

            if ($scope.RecipeForm.$valid) {
                $scope.submitting = true;
                     
                // alert("save");
                apiService.post('/api/recipies/add', $scope.recipe,
                addRecipeSucceded,
                addRecipeFailed);
            }
        }

        function prepareFiles($files) {
            movieImage = $files;
        }

        function addRecipeSucceded(response) {
            notificationService.displaySuccess($scope.recipe.Name + ' has been submitted to Home Cinema');
          //  $scope.movie = response.data;

         //  if (movieImage) {
        //        fileUploadService.uploadImage(movieImage, $scope.movie.ID, redirectToEdit);
         //   }
          //  else
           //     redirectToEdit();
        }

        function addRecipeFailed(response) {
            console.log(response);
            notificationService.displayError(response.statusText);
        }

       

        function redirectToEdit() {
            $location.url('movies/edit/' + $scope.movie.ID);
        }

       

        loadcategories();
        loadunits();
    }

})(angular.module('easychefdemo'));