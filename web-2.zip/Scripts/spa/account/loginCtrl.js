﻿(function (app) {
    'use strict';

    app.controller('loginCtrl', loginCtrl);

    loginCtrl.$inject = ['$scope', 'membershipService', 'notificationService', '$rootScope', '$location' ,'$state','apiService'];

    function loginCtrl($scope, membershipService, notificationService, $rootScope, $location, $state, apiService) {
        $scope.pageClass = 'page-login';
        $scope.login = login;
        $scope.user = {};
        $scope.showSpinner = false;
        $scope.showUserNameError = false;
        $scope.showUserNameSuccess = false;

        $scope.showForgotPasswordSuccess = true;
        $scope.showResetPasswordSuccess = false;
        

        $scope.forgotPassword = forgotPassword;
        $scope.resetPassword = resetPassword;


        
        
       // alert("login");
        function login() {
            $scope.showSpinner = true;
            membershipService.login($scope.user, loginCompleted, loginFailed)
        }

        function loginCompleted(result) {

            $scope.showSpinner = false;
            if (result.data.success) {
                membershipService.saveCredentials($scope.user);
                notificationService.displaySuccess('Hello ' + $scope.user.Username);
                $scope.userData.displayUserInfo();
                if ($rootScope.previousState)
                    $location.path($rootScope.previousState);
                else
                    $state.go('Management.Profile');
                    //$location.path('Management.profile');
                  //  $location.path('Management');
            }
            else {
                $scope.showUserNameError = true;
               // notificationService.displayError('Login failed. Try again.');
            }
        }

        function loginFailed(response) {
            $scope.showSpinner = false;
            console.log(response);
            $scope.showUserNameError = true;
            //notificationService.displayError(response.statusText);
        }

        //------------------------------------------ Forgot password
      



        function forgotPassword() {
            $scope.showSpinner = true;
            apiService.post('/api/account/forgotpassword', $scope.user,
           forgotpasswordCompleted,
           forgotpasswordFailed);

         
        }


        function forgotpasswordCompleted(response) {
           
            $scope.showSpinner = false;
            
            console.log(response);
            $scope.showUserNameError = false;
            $scope.showUserNameSuccess = true;
            $scope.showForgotPasswordSuccess = false;
            
            $scope.showResetPasswordSuccess = true;
           
        }

        function forgotpasswordFailed(response) {
            $scope.showSpinner = false;        
            console.log(response);
            $scope.showUserNameError = true;
            $scope.showUserNameSuccess = false;
            
        }
        //---------------------------------------
        function resetPassword() {
            $scope.showSpinner = true;
            apiService.post('/api/account/resetpassword', $scope.user,
           resetPasswordCompleted,
           resetPasswordFailed);


        }


        function resetPasswordCompleted(response) {

            $scope.showSpinner = false;

            console.log(response);
            $scope.showUserNameError = false;
            $scope.showUserNameSuccess = true;
            $scope.showForgotPasswordSuccess = false;

            $scope.showResetPasswordSuccess = true;

        }

        function resetPasswordFailed(response) {
            $scope.showSpinner = false;
            console.log(response);
            $scope.showUserNameError = true;
            $scope.showUserNameSuccess = false;

        }

    }

})(angular.module('common.core'));