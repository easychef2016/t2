﻿(function (app) {
    'use strict';

    app.controller('inventoryItemAddCtrl', inventoryItemAddCtrl);

    inventoryItemAddCtrl.$inject = ['$scope', '$location', '$timeout', 'apiService', 'notificationService','$rootScope'];

    function inventoryItemAddCtrl($scope, $location, $timeout, apiService, notificationService, $rootScope) {
       // alert("inventory-test");
        //  $scope.pageClass = 'page-InventoryItems';
        $scope.categories = [];
        $scope.units = [];
        $scope.vendors = [];
      //  $scope.InventoryItems = [];
        $scope.DeleteInventoryItem = DeleteInventoryItem;
        $scope.addInventoryItem = addInventoryItem;
        $scope.CreateInventoryItem = CreateInventoryItem;
        $scope.InventoryItemList = {}
        $scope.submitted = false;
        $scope.submitting = false;
        $scope.date = '19/03/2016';
        $scope.InventoryItems = [];

        $scope.filterUsername = '';
        function loadUserdata() {

            if ($rootScope.repository.loggedUser) {
                $scope.filterUsername = $rootScope.repository.loggedUser.username;

            }
        }

     

        function initializeInventoryItems() {
            $scope.InventoryItems = [
            {
                'Name': '',
                'ItemDescription': '',
                'UnitId': '',
                'Quantity': '',
                'Price': '',
                'PriceDate': new Date().toLocaleDateString(),
                'VendorId': '',
                'CategoryId': ''

            }];
        }

        //$scope.categories = [
        //{
        //    'ID': '1',
        //    'Name': 'Indian Food'
        //}];

              
        //----Date Picker - start
        $scope.openDatePicker = openDatePicker;
        $scope.dateOptions = {
            formatYear: 'yy',
            startingDay: 1
        };
        $scope.datepicker = {};

        function openDatePicker($event) {
            $event.preventDefault();
            $event.stopPropagation();

            $scope.datepicker.opened = true;
        };


        //--Date Picker  - End
       

       
       

      

        $scope.openDatePicker = openDatePicker;
        $scope.dateOptions = {
            formatYear: 'yy',
            startingDay: 1
        };
        $scope.datepicker = {};
        
        //$scope.isReadOnly = false;
        //$scope.AddInventoryItem = AddInventoryItem;
        //$scope.prepareFiles = prepareFiles;

        //$scope.openDatePicker = openDatePicker;
        //$scope.changeNumberOfStocks = changeNumberOfStocks;

        //$scope.dateOptions = {
        //    formatYear: 'yy',
        //    startingDay: 1
        //};
        //$scope.datepicker = {};

        //var InventoryItemImage = null;

        function loadcategories() {
            apiService.get('/api/categories/latest', null,
            categoriesLoadCompleted,
            categoriesLoadFailed);
        }

        function categoriesLoadCompleted(response) {
            $scope.categories = response.data;
        }

        function categoriesLoadFailed(response) {
            console.log(response);
            notificationService.displayError(response.statusText);
        }


        function loadvendors() {

            var config = {
                params: {

                    filter: $scope.filterUsername
                }
            };
            apiService.get('/api/vendors/latest', config,
            vendorsLoadCompleted,
            vendorsLoadFailed);
        }

        function vendorsLoadCompleted(response) {
            $scope.vendors = response.data;
        }

        function vendorsLoadFailed(response) {
            console.log(response);
            notificationService.displayError(response.statusText);
        }

        function loadunits() {
            apiService.get('/api/units//latest', null,
            unitsLoadCompleted,
            unitsLoadFailed);
        }

        function unitsLoadCompleted(response) {
            $scope.units = response.data;
        }

        function unitsLoadFailed(response) {
            console.log(response);
            notificationService.displayError(response.statusText);
        }


        
        //function AddInventoryItem() {
        //    AddInventoryItemModel();
        //}

        //function AddInventoryItemModel() {
        //    apiService.post('/api/InventoryItems/add', $scope.InventoryItem,
        //    addInventoryItemSucceded,
        //    addInventoryItemFailed);
        //}

        //function prepareFiles($files) {
        //    InventoryItemImage = $files;
        //}

        //function addInventoryItemSucceded(response) {
        //    notificationService.displaySuccess($scope.InventoryItem.Title + ' has been submitted to Home Cinema');
        //    $scope.InventoryItem = response.data;

        //    if (InventoryItemImage) {
        //        fileUploadService.uploadImage(InventoryItemImage, $scope.InventoryItem.ID, redirectToEdit);
        //    }
        //    else
        //        redirectToEdit();
        //}

        //function addInventoryItemFailed(response) {
        //    console.log(response);
        //    notificationService.displayError(response.statusText);
        //}

        //function openDatePicker($event) {
        //    $event.preventDefault();
        //    $event.stopPropagation();

        //    $scope.datepicker.opened = true;
        //};

        //function redirectToEdit() {
        //    $location.url('InventoryItems/edit/' + $scope.InventoryItem.ID);
        //}

        //function changeNumberOfStocks($vent) {
        //    var btn = $('#btnSetStocks'),
        //    oldValue = $('#inputStocks').val().trim(),
        //    newVal = 0;

        //    if (btn.attr('data-dir') == 'up') {
        //        newVal = parseInt(oldValue) + 1;
        //    } else {
        //        if (oldValue > 1) {
        //            newVal = parseInt(oldValue) - 1;
        //        } else {
        //            newVal = 1;
        //        }
        //    }
        //    $('#inputStocks').val(newVal);
        //    $scope.InventoryItem.NumberOfStocks = newVal;
        //    console.log($scope.InventoryItem);
        //}


      
        //$scope.AddInventoryItemControl = function () {
        //    var divElement = angular.element(document.querySelector('#inventoryItemDiv'));
        //    var appendHtml = $compile('<inventory-Item></inventory-Item>')($scope);
        //    divElement.append(appendHtml);
        //}


        function openDatePicker($event) {
            //alert("date");
            $event.preventDefault();
            $event.stopPropagation();

            //$scope.datepicker.opened = true;
            //alert($scope.datepicker.opened);

            $timeout(function () {
                $scope.datepicker.opened = true;
            });
            
                      $timeout(function () {
                               $('ul[datepicker-popup-wrap]').css('z-index', '10000');
                          }, 100);
        };

        function DeleteInventoryItem(index) {
            $scope.InventoryItems.splice(index, 1);
        }

        function addInventoryItem() {
           
            $scope.InventoryItems.push(
            {
                'Name': '',
                'ItemDescription': '',
                'UnitId': '',
                'Quantity': '',
                'Price': '',
                'PriceDate': new Date().toLocaleDateString(),
                'VendorId': '',
                'CategoryId': ''

            });
        }

        function CreateInventoryItem() {

          

            $scope.submitted = true;
           // alert($scope.InventoryItemsForm.$valid);
            if ($scope.InventoryItemsForm.$valid) {
                $scope.submitting = true;
                //$scope..InventoryItems =
               // debugger;
                //  $scope.InventoryItemList = angular.copy($scope.InventoryItems);
                var InventoryItemList = {};
                InventoryItemList = angular.copy($scope.InventoryItems);
                //alert($scope.InventoryItemList);
                apiService.post('/api/inventoryitems/add', InventoryItemList,
                    createInventoryItemSucceded,
                    createInventoryItemFailed);
               


            }



        }

       
        function createInventoryItemSucceded(response) {
            notificationService.displaySuccess('Inventory Item has been submitted ');
            $scope.submitting = false;
            initializeInventoryItems();

        }

        function createInventoryItemFailed(response) {
            notificationService.displayError(response.data);
            $scope.submitting = false;
        }

        
        loadUserdata();
        loadcategories();
        loadvendors();
        loadunits();
        initializeInventoryItems();
    

    }

})(angular.module('easychefdemo'));