﻿(function (app) {
    'use strict';

    app.controller('inventoryItemEditCtrl', inventoryItemEditCtrl);

    inventoryItemEditCtrl.$inject = ['$scope', '$location', '$stateParams', 'apiService', 'notificationService','$rootScope'];

    function inventoryItemEditCtrl($scope, $location, $stateParams, apiService, notificationService, $rootScope) {
       
        //  $scope.pageClass = 'page-InventoryItems';

        $scope.categories = [];
        $scope.units = [];
        $scope.vendors = [];
      
      
      
        $scope.submitted = false;
        $scope.submitting = false;
     
        

        $scope.loadingInventoryItems = true;
        $scope.InventoryItem = {};

        $scope.UpdateinventoryItemModel = UpdateinventoryItemModel;
      
        $scope.filterUsername = '';
        function loadUserdata() {

            if ($rootScope.repository.loggedUser) {
                $scope.filterUsername = $rootScope.repository.loggedUser.username;

            }
        }
        loadUserdata();
           

        function loadcategories() {
            apiService.get('/api/categories/latest', null,
            categoriesLoadCompleted,
            categoriesLoadFailed);
        }

        function categoriesLoadCompleted(response) {
            $scope.categories = response.data;
        }

        function categoriesLoadFailed(response) {
            notificationService.displayError(response.data);
        }


        function loadvendors() {
            var config = {
                params: {

                    filter: $scope.filterUsername
                }
            };
            apiService.get('/api/vendors/latest', config,
            vendorsLoadCompleted,
            vendorsLoadFailed);
        }

        function vendorsLoadCompleted(response) {
            $scope.vendors = response.data;
        }

        function vendorsLoadFailed(response) {
            notificationService.displayError(response.data);
        }

        function loadunits() {
            apiService.get('/api/units/latest', null,
            unitsLoadCompleted,
            unitsLoadFailed);
        }

        function unitsLoadCompleted(response) {
            $scope.units = response.data;
        }

        function unitsLoadFailed(response) {
            notificationService.displayError(response.data);
        }


        function loadInventoryItem() {
            $scope.loadingInventoryItems = true;
            apiService.get('/api/inventoryitems/details/' + $stateParams.ItemId, null,
            inventoryItemLoadCompleted,
            inventoryItemLoadFailed);
        }


        function inventoryItemLoadCompleted(response) {
            $scope.InventoryItem = response.data;
            $scope.loadingInventoryItems = false;
         
            loadcategories();
            loadvendors();
            loadunits();

        }

        function inventoryItemLoadFailed(response) {
         
            notificationService.displayError(response.data);
            $scope.submitting = false;
        }


        function UpdateinventoryItemModel() {
           // alert("update ")
            $scope.submitted = true;

            if ($scope.InventoryItemEditForm.$valid) {
                $scope.submitting = true;
                apiService.post('/api/inventoryitems/update', $scope.InventoryItem,
                updateinventoryItemSucceded,
                updateinventoryItemSFailed);
            }
        }

       

        function updateinventoryItemSucceded(response) {
            console.log(response);
            notificationService.displaySuccess($scope.InventoryItem.Name + ' has been updated');
            $scope.InventoryItem = response.data;
           // movieImage = null;
        }

        function updateinventoryItemSFailed(response) {
            notificationService.displayError(response);
        }

           
        
        loadInventoryItem();

        

       
        



    }

})(angular.module('easychefdemo'));