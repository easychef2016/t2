﻿(function () {
    'use strict';       
    angular.module('easychefdemo', ['common.core', 'common.ui'])
        .config(config)
        .run(run);

    config.$inject = ['$stateProvider', '$urlRouterProvider', '$cookiesProvider', '$locationProvider','$mdThemingProvider','$mdIconProvider'];

    function config($stateProvider, $urlRouterProvider, $cookiesProvider, $locationProvider, $mdThemingProvider, $mdIconProvider) {

        $urlRouterProvider.otherwise('/');

        $stateProvider
            .state('home', {
                url: '/',
                templateUrl: '/scripts/spa/home/index.html',
                controller: 'rootCtrl',
                authenticate: false
            })   
            .state('login', {
                url: '/login',
                templateUrl: '/scripts/spa/account/login.html',
                controller: 'loginCtrl',
                authenticate: false
            })

            .state('forgotpassword', {
              url: '/forgotpassword',
              templateUrl: '/scripts/spa/account/forgotpassword.html',
              controller: 'loginCtrl',
              authenticate: false
            })
            .state('register', {
                url: '/register',
                templateUrl: '/scripts/spa/account/register.html',
                controller: 'restaurantRegisterCtrl',
                authenticate: false

            })
            .state('welcome', {
                url: '/welcome',
                templateUrl: '/scripts/spa/account/welcome.html',
                controller: 'restaurantRegisterCtrl',
                authenticate: false

            })
            .state('Management', {
                 url: '/Management',
                 templateUrl: '/scripts/spa/layout/main.html',
                  authenticate: true
             })
             .state('Management.Profile', {
                 url: '/dashboard',
                 templateUrl: '/scripts/spa/Dashboard/profile.html',
                 controller: 'dashboardCtrl',
                 authenticate: true
             })
            .state('Management.recipies', {
                url: '/recipies',
                templateUrl: '/scripts/spa/recipies/recipies.html',
                controller: 'recipiesCtrl',
                authenticate: true
            })
            .state('Management.recipiesadd', {
                url: '/add',
                templateUrl: '/scripts/spa/recipies/recipieAdd.html',
                controller: 'recipeAddCtrl',
                authenticate: true
            })
            .state('Management.recipies.edit', {
                url: '/Management/recipies/edit/{recipieId:[0-9]{1,5}}',
                templateUrl: '/scripts/spa/recipies/recipieAdd.html',
                authenticate: true
           })
            .state('Management.recipies.detail', {
                url: '/Management/recipies/detail/{recipieId:[0-9]{1,5}}',
                templateUrl: '/scripts/spa/recipies/recipieAdd.html',
                authenticate: true         
            })
            .state('Management.inventoryitem', {
                url: '/inventoryitems',
                templateUrl: '/scripts/spa/inventoryitems/inventoryitems.html',
                controller: 'inventoryItemsCtrl',
                authenticate: true
            })
            .state('Management.inventoryitemadd', {
                url: '/inventoryitemsadd',
                templateUrl: '/scripts/spa/inventoryitems/inventoryitemAdd.html',
                controller: 'inventoryItemAddCtrl',
                authenticate: true
            })
            .state('Management.inventoryitemedit', {
                 url: '/inventoryitemsedit/{ItemId:[0-9]{1,5}}',
                templateUrl: '/scripts/spa/inventoryitems/inventoryItemEdit.html',
                controller: 'inventoryItemEditCtrl',
                authenticate: true
            })
            .state('Management.category', {
                url: '/category',
                templateUrl: '/scripts/spa/settings/categories.html',
                controller: 'categoriesCtrl',
                authenticate: true
            })
            .state('Management.categoryadd', {
                url: '/categoryAdd',
                templateUrl: '/scripts/spa/settings/categoryAdd.html',
                controller: 'categoryItemAddCtrl',
            })
            .state('Management.categoryedit', {
                url: '/categoryEdit/{ItemId:[0-9]{1,5}}',
                templateUrl: '/scripts/spa/settings/categoryEdit.html',
                controller: 'categoryItemEditCtrl',
                authenticate: true

            })
            .state('Management.unitdetails', {
                url: '/unit',
                templateUrl: '/scripts/spa/settings/unitDetails.html',
                controller: 'unitDetailsCtrl',
                authenticate: true
            
            })
            .state('Management.unitadd', {
                url: '/unitAdd',
                templateUrl: '/scripts/spa/settings/unitAdd.html',
                controller: 'unitItemAddCtrl',
                authenticate: true
            })

            .state('Management.unitedit', {
                url: '/categoryEdit/{ItemId:[0-9]{1,5}}',
                templateUrl: '/scripts/spa/settings/categoryEdit.html',
                controller: 'unitEditCtrl',
                authenticate: true
            })
            .state('Management.inventoryadd', {
                url: '/inventoryadd',
                templateUrl: '/scripts/spa/inventorysheet/inventoryAdd.html',
                controller: 'inventoryAddCtrl',
                authenticate: true
            })
            .state('Management.inventorydetails', {
                url: '/inventorydetails',
                templateUrl: '/scripts/spa/inventorysheet/inventoryDetails.html',
                controller: 'inventoryDetailsCtrl',
                authenticate: true             
            })
            .state('Management.inventoryEdit', {
                url: '/inventoryEdit/{id:[0-9]{1,5}}',
                templateUrl: '/scripts/spa/inventorysheet/inventoryEdit.html',
                controller: 'inventoryEditCtrl',
                authenticate: true
            
            })
            .state('Management.inventoryinvoice', {
                url: '/inventoryinvoice/{id:[0-9]{1,5}}',
                templateUrl: '/scripts/spa/inventorysheet/InventoryInvoice.html',
                controller: 'InventoryInvoiceCtrl',
                authenticate: true
         
            })
            .state('Management.vendordetails', {
                url: '/vendordetails',
                templateUrl: '/scripts/spa/vendor/vendors.html',
                controller: 'vendorsCtrl',
                authenticate: true
            })
            .state('Management.vendoradd', {
                url: '/vendoradd',
                templateUrl: '/scripts/spa/vendor/vendoradd.html',
                controller: 'vendorAddCtrl',
                authenticate: true
         
            })
            .state('Management.vendorEdit', {
                url: '/vendorEdit/{id:[0-9]{1,5}}',
                templateUrl: '/scripts/spa/vendor/vendorEdit.html',
                controller: 'vendorEditCtrl',
                authenticate: true
            
            })
            .state('Management.usersdetails', {
               url: '/usersdetails',
               templateUrl: '/scripts/spa/admin/UserManagement/users.html',
               controller: 'usersCtrl',
               authenticate: true
            })

            .state('Management.UserManagement', {
                url: '/usermanagement',
                templateUrl: '/scripts/spa/Dashboard/usermanagment.html',
                controller: 'usermanagementCtrl',
                authenticate: true
            })
          


        $mdThemingProvider.theme('default')
         .primaryPalette('blue', {
             'default': '500', // by default use shade 400 from the cyan palette for primary intentions
             'hue-1': 'A200', // use shade 100 for the <code>md-hue-1</code> class
             'hue-2': 'A400', // use shade 600 for the <code>md-hue-2</code> class
             'hue-3': 'A700' // use shade A100 for the <code>md-hue-3</code> class
         })
         .accentPalette('green', {
             'default': 'A700' // use shade 200 for default, and keep all other shades the same
         })
         .warnPalette('red')
        .backgroundPalette('grey');
      
    
    }

    run.$inject = ['$rootScope', '$location', '$cookies', '$http', '$state', 'membershipService'];

    function run($rootScope, $location, $cookies, $http, $state, membershipService) {

        $rootScope.repository = $cookies.getObject('repository') || {};
         if ($rootScope.repository.loggedUser) {
               $http.defaults.headers.common['Authorization'] = $rootScope.repository.loggedUser.authdata;
         }

         $rootScope.$on("$stateChangeStart", function (event, toState, toParams, fromState, fromParams) {

             if (toState.authenticate && !membershipService.isUserLoggedIn()) {

                 $rootScope.repository = $cookies.getObject('repository') || {};

                 if ($rootScope.repository.loggedUser) {
                     $http.defaults.headers.common['Authorization'] = $rootScope.repository.loggedUser.authdata;
                 }
                else {
                    $rootScope.previousState = $location.path();
                    $state.go("login");
                    event.preventDefault();
                }               
             }
         });


         $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
                  $rootScope.url = $state.current.name;
            
            
         });



         $(document).ready(function () {
             $(".fancybox").fancybox({
                 openEffect: 'none',
                 closeEffect: 'none'
             });

             $('.fancybox-media').fancybox({
                 openEffect: 'none',
                 closeEffect: 'none',
                 helpers: {
                     media: {}
                 }
             });

             $('[data-toggle=offcanvas]').click(function () {
                 $('.row-offcanvas').toggleClass('toggled');
             });


             $('[menu-toggle]').click(function () {
                 $('menu-toggle').toggleClass('active');
             });


            

             $('#datePicker')
              .datepicker({
                  autoclose: true,
                  format: 'mm/dd/yyyy'
              });
               
             //Date picker
             $('#datepicker').datepicker({
                 autoclose: true
             });


         });

         $(window).scroll(function () {
             $(".navbar").offset().top > 50 ? $(".navbar-fixed-top").addClass("top-nav-collapse") : $(".navbar-fixed-top").removeClass("top-nav-collapse")
         });

       
    }


   

 
  
})();


