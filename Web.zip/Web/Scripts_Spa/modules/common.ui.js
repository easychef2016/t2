﻿(function () {
    'use strict';

    // var app = angular.module('easychefdemo', ['ui.router', 'ngAnimate', 'ui.bootstrap', 'ngMapModule']);
    //Version 1.0
    //angular.module('common.ui', ['ui.bootstrap', 'ngAnimate', 'chieffancypants.loadingBar']);

    //V1.1
    //angular.module('common.ui', ['ngMaterial',  'ngAnimate', 'chieffancypants.loadingBar']);

    //V1.2
    ///angular.module('common.ui', ['ui.bootstrap', 'ngAnimate', 'chieffancypants.loadingBar']);

    //V1.3
    //angular.module('common.ui', ['ui.materialize', 'ui.bootstrap', 'ngAria', 'ngAnimate', 'ngMaterial', 'chieffancypants.loadingBar', 'mdDataTable', 'ngMask']);
    //V1.4
    angular.module('common.ui', ['ui.bootstrap', 'ui.utils', 'ngAria', 'ngAnimate', 'ngMaterial', 'chieffancypants.loadingBar', 'ngMask','mdDataTable', 'angularSmoothscroll']);


   
})();