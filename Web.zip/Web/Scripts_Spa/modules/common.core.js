﻿(function () {
	'use strict';
    /// var app = angular.module('easychefdemo', ['ui.router', 'ngAnimate', 'ui.bootstrap', 'ngMapModule']);
    //V1.0
	//angular.module('common.core', ['ui.router', 'ngCookies', 'base64', 'angularFileUpload', 'angularValidator', 'angucomplete-alt']);

    //V1.1
	//angular.module('common.core', ['ui.router', 'ngCookies', 'base64', 'ngSanitize', 'smart-table', 'angularFileUpload', 'angularValidator', 'angucomplete-alt', 'toggle-switch', 'uiSwitch', 'ngMapModule', 'ngAutocomplete']);

    //V1.2
	angular.module('common.core', ['ui.router', 'ngCookies', 'base64', 'ngSanitize', 'smart-table', 'angularFileUpload', 'angularValidator', 'angucomplete-alt', 'toggle-switch', 'uiSwitch', 'vsGoogleAutocomplete', 'ngPrint', 'msFormWizard', 'md-steppers', 'ui.directives', 'ui.filters']);

	
})();