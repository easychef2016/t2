﻿
using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

using System.Web.Mvc;
using EasyChefDemo.Web.Infrastructure.Validators;


namespace EasyChefDemo.Web.Models
{
    public class DashboardViewModel : IValidatableObject
    {
        public int ID { get; set; }

        public string InventorytotalToday { get; set; }

        public string InventorytotalMonthly { get; set; }

        public string InventorySubmittedToday { get; set; }
     

       
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var validator = new DashboardViewModelValidator();
            var result = validator.Validate(this);
            return result.Errors.Select(item => new ValidationResult(item.ErrorMessage, new[] { item.PropertyName }));
        }
    }
}