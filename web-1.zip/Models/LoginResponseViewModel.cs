﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EasyChefDemo.Web.Models
{
    public class LoginResponseViewModel
    {
        public int Id { get; set; }
        public string AccountType { get; set; }
        public bool IsAdmin { get; set; }
        public string EmailId { get; set; }
        public string Password { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string UserImage { get; set; }
        public string MobileNo { get; set; }
        public object AccessToken { get; set; }
        public string ModifyDate { get; set; }
        public string Username { get; set; }
    }
}