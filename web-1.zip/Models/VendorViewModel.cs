﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EasyChefDemo.Web.Models
{
    [Bind(Exclude = "Image")]
    public class VendorViewModel
    {
        public int ID { get; set; }
        public string Image { get; set; }
        public string Name { get; set; }
        public string SalesAgent { get; set; }
        public bool DotNotCopy { get; set; }
        public string Description { get; set; }

        //Added on 08212016
        public string loginUserInfo { get; set; }

        public bool Status { get; set; }

        public Nullable<DateTime> CreatedDate { get; set; }
        public String CreatedBy { get; set; }
        public Nullable<DateTime> UpdatedDate { get; set; }
        public String UpdatedBy { get; set; }


        public IList<AddressViewModel> VendorAddresses { get; set; }
        public IList<ContactsViewModel> VendorContacts { get; set; }


     

       
    }
}