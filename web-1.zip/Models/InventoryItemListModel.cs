﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace EasyChefDemo.Web.Models
{
    public class InventoryItemListModel 
    {

        public InventoryItemListModel()
        {
          
            InventoryItems = new List<InventoryItemViewModel>();
        }

        public IList<InventoryItemViewModel> InventoryItems { get; set; }


    }
}