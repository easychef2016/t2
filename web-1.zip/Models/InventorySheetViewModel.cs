﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


using System.ComponentModel.DataAnnotations;
using EasyChefDemo.Entities;
using EasyChefDemo.Web.Infrastructure.Validators;

namespace EasyChefDemo.Web.Models
{
    public class InventorySheetViewModel : IValidatableObject
    {
        public InventorySheetViewModel()
        {
            ApprovedInventories = new List<ApprovedInventoryViewModel>();
           
        }

        public int ID { get; set; }

        public string Name { get; set; }

        public string Restaurant { get; set; }
        public int RestaurantId { get; set; }

        public string Vendor { get; set; }
        public int VendorId { get; set; }
       

        public Nullable<DateTime> InventoryDate { get; set; }
           
        public IList<ApprovedInventoryViewModel> ApprovedInventories { get; set; }
        public IList<InventoryItemViewModel> InventoryItems { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var validator = new InventorySheetViewModelValidators();
            var result = validator.Validate(this);
            return result.Errors.Select(item => new ValidationResult(item.ErrorMessage, new[] { item.PropertyName }));
        }
    }
}