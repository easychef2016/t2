﻿using EasyChefDemo.Web.Infrastructure.Validators;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EasyChefDemo.Web.Models
{
     [Bind(Exclude = "Image")]
    public class InventoryItemViewModel : IValidatableObject
    {

        public int ID { get; set; }

        public string Name { get; set; }
        public string ItemDescription { get; set; }

        public int UnitId { get; set; }
        public string Unit { get; set; }

        public decimal? Quantity { get; set; }
        public decimal? Price { get; set; }

        public Nullable<DateTime> PriceDate { get; set; }  //Current Date show on screen default
       
        public int VendorId { get; set; }
        public string Vendor { get; set; }
        public int CategoryId { get; set; }
        public string Category { get; set; }

        public int IngredientTypeId { get; set; }
        public string IngredientType { get; set; }

        // public int RestaurantId { get; set; }
        // public Restaurant Restaurant { get; set; }

        public string Image { get; set; }


        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var validator = new InventoryItemViewModelValidator();
            var result = validator.Validate(this);
            return result.Errors.Select(item => new ValidationResult(item.ErrorMessage, new[] { item.PropertyName }));
        }

    }
}