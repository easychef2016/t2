﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.ComponentModel.DataAnnotations;
using EasyChefDemo.Web.Infrastructure.Validators;

namespace EasyChefDemo.Web.Models
{
    public class ContactsViewModel : IValidatableObject
    {

        public int ID { get; set; }
        public string Email { get; set; }
        public string WebsiteURL { get; set; }
        public string CellPhone { get; set; }
        public string WorkPhone { get; set; }
        public string Fax { get; set; }

        public bool Status { get; set; }
        public Nullable<DateTime> CreatedDate { get; set; }
        public String CreatedBy { get; set; }
        public Nullable<DateTime> UpdatedDate { get; set; }
        public String UpdatedBy { get; set; }

        public int VendorId { get; set; }
        public string Vendor { get; set; }

        public int RestaurantId { get; set; }
        public string Restaurant { get; set; }

        public int UserId { get; set; }
        public string User { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var validator = new ContactsViewModelValidator();
            var result = validator.Validate(this);
            return result.Errors.Select(item => new ValidationResult(item.ErrorMessage, new[] { item.PropertyName }));
        }
    }
}