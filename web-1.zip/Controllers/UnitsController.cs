﻿using AutoMapper;
using EasyChefDemo.Data.Infrastructure;
using EasyChefDemo.Data.Repositories;
using EasyChefDemo.Entities;
using EasyChefDemo.Web.Infrastructure.Core;
using EasyChefDemo.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using EasyChefDemo.Web.Infrastructure.Extensions;
using EasyChefDemo.Web.Infrastructure.Filters;
namespace EasyChefDemo.Web.Controllers
{
     [DeflateCompression]
    [Authorize(Roles = "Admin")]
    [RoutePrefix("api/units")]
    public class UnitsController : ApiControllerBase
    {
        private readonly IEntityBaseRepository<Unit> _unitsRepository;

        public UnitsController(IEntityBaseRepository<Unit> unitsRepository,
             IEntityBaseRepository<Error> _errorsRepository, IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _unitsRepository = unitsRepository;
        }

        [AllowAnonymous]
        [Route("latest")]
        public HttpResponseMessage Get(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
               // var units = _unitsRepository.GetAll().ToList();

                var units = _unitsRepository.GetAll().OrderByDescending(it => it.CreatedDate).ToList();

                IEnumerable<UnitViewModel> unitsVM = Mapper.Map<IEnumerable<Unit>, IEnumerable<UnitViewModel>>(units);

                response = request.CreateResponse<IEnumerable<UnitViewModel>>(HttpStatusCode.OK, unitsVM);

                return response;
            });
        }
        [HttpPost]
        [Route("add")]
        public HttpResponseMessage Add(HttpRequestMessage request, List<Unit> unitsList)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                }
                else
                {
                    Unit newunitItem = new Unit();
                    if (unitsList != null)
                    {
                        foreach (var unit in unitsList)
                        {
                             newunitItem.UpdateUnitItemAdd(unit);
                            _unitsRepository.Add(newunitItem);
                            _unitOfWork.Commit();
                        }
                    }


                    response = request.CreateResponse(HttpStatusCode.OK, new { success = true });

                    //// Update view model
                    //unitVM = Mapper.Map<Unit, UnitViewModel>(unitItemDb);
                    //response = request.CreateResponse<UnitViewModel>(HttpStatusCode.Created, unitVM);

                    
                }

                return response;
            });
        }


        [HttpPost]
        [Route("update")]
        public HttpResponseMessage Update(HttpRequestMessage request, UnitViewModel unitVM)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                }
                else
                {
                    var unitItemDb = _unitsRepository.GetSingle(unitVM.ID);
                    if (unitItemDb == null)
                        response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid Unit.");
                    else
                    {
                        unitItemDb.UpdateUnitItemEdit(unitVM);
                        _unitsRepository.Edit(unitItemDb);

                        _unitOfWork.Commit();

                        //// Update view model
                        unitVM = Mapper.Map<Unit, UnitViewModel>(unitItemDb);
                        response = request.CreateResponse<UnitViewModel>(HttpStatusCode.Created, unitVM);
                        
                    }
                }

                return response;
            });
        }

       

    }



     [Authorize(Roles = "Admin")]
     [RoutePrefix("mobileapi/units")]
     public class MobileUnitsController : ApiControllerBase
     {
         private readonly IEntityBaseRepository<Unit> _unitsRepository;

         public MobileUnitsController(IEntityBaseRepository<Unit> unitsRepository,
              IEntityBaseRepository<Error> _errorsRepository, IUnitOfWork _unitOfWork)
             : base(_errorsRepository, _unitOfWork)
         {
             _unitsRepository = unitsRepository;
         }

         [AllowAnonymous]
         [Route("latest")]
         public HttpResponseMessage Get(HttpRequestMessage request)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;
                 // var units = _unitsRepository.GetAll().ToList();

                 var units = _unitsRepository.GetAll().OrderByDescending(it => it.CreatedDate).ToList();

                 IEnumerable<UnitViewModel> unitsVM = Mapper.Map<IEnumerable<Unit>, IEnumerable<UnitViewModel>>(units);

                 response = request.CreateResponse<IEnumerable<UnitViewModel>>(HttpStatusCode.OK, unitsVM);

                 return response;
             });
         }


          [AllowAnonymous]
         [HttpPost]
         [Route("add")]
         public HttpResponseMessage Add(HttpRequestMessage request, List<Unit> unitsList)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;

                 if (!ModelState.IsValid)
                 {
                     response = request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                 }
                 else
                 {
                     Unit newunitItem = new Unit();
                     if (unitsList != null)
                     {
                         foreach (var unit in unitsList)
                         {
                             newunitItem.UpdateUnitItemAdd(unit);
                             _unitsRepository.Add(newunitItem);
                             _unitOfWork.Commit();
                         }
                     }


                     response = request.CreateResponse(HttpStatusCode.OK, new { success = true });

                     //// Update view model
                     //unitVM = Mapper.Map<Unit, UnitViewModel>(unitItemDb);
                     //response = request.CreateResponse<UnitViewModel>(HttpStatusCode.Created, unitVM);


                 }

                 return response;
             });
         }


          [AllowAnonymous]
         [HttpPost]
         [Route("update")]
         public HttpResponseMessage Update(HttpRequestMessage request, UnitViewModel unitVM)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;

                 if (!ModelState.IsValid)
                 {
                     response = request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                 }
                 else
                 {
                     var unitItemDb = _unitsRepository.GetSingle(unitVM.ID);
                     if (unitItemDb == null)
                         response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid Unit.");
                     else
                     {
                         unitItemDb.UpdateUnitItemEdit(unitVM);
                         _unitsRepository.Edit(unitItemDb);

                         _unitOfWork.Commit();

                         //// Update view model
                         unitVM = Mapper.Map<Unit, UnitViewModel>(unitItemDb);
                         response = request.CreateResponse<UnitViewModel>(HttpStatusCode.Created, unitVM);

                     }
                 }

                 return response;
             });
         }



     }
}
