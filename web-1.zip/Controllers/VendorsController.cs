﻿using AutoMapper;
using EasyChefDemo.Data.Infrastructure;
using EasyChefDemo.Data.Repositories;
using EasyChefDemo.Entities;
using EasyChefDemo.Web.Infrastructure.Core;
using EasyChefDemo.Web.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

using EasyChefDemo.Web.Infrastructure.Extensions;
using EasyChefDemo.Data.Extensions;
using EasyChefDemo.Web.Infrastructure.Filters;

namespace EasyChefDemo.Web.Controllers
{
     [DeflateCompression]
    
    [Authorize(Roles = "Admin")]
    [RoutePrefix("api/vendors")]
    public class VendorsController : ApiControllerBase
    {
        private readonly IEntityBaseRepository<Vendor> _vendorsRepository;
        private readonly IEntityBaseRepository<Inventory> _inventoryRepository;

        private readonly IEntityBaseRepository<Address> _addressRepository;
        private readonly IEntityBaseRepository<VendorAddress> _vendoraddressRepository;
        private readonly IEntityBaseRepository<User> _userRepository;
        private readonly IEntityBaseRepository<Restaurant> _restaurantRepository;

        private readonly IEntityBaseRepository<Contacts> _contactsRepository;

        public VendorsController(IEntityBaseRepository<Vendor> vendorsRepository,
            IEntityBaseRepository<Address> addressRepository,
            IEntityBaseRepository<VendorAddress> vendoraddressRepository,
            IEntityBaseRepository<Inventory> inventoryRepository,
            IEntityBaseRepository<User> userRepository,
            IEntityBaseRepository<Restaurant> restaurantRepository,
            IEntityBaseRepository<Contacts> contactsRepository,
             IEntityBaseRepository<Error> _errorsRepository, IUnitOfWork _unitOfWork)
            : base(_errorsRepository, _unitOfWork)
        {
            _vendorsRepository = vendorsRepository;
            _addressRepository = addressRepository;
            _vendoraddressRepository = vendoraddressRepository;
            _inventoryRepository = inventoryRepository;
            _userRepository = userRepository;
            _restaurantRepository = restaurantRepository;
            _contactsRepository = contactsRepository;

        }

        //[AllowAnonymous]
        //public HttpResponseMessage Get(HttpRequestMessage request ,string filter)
        //{
        //    return CreateHttpResponse(request, () =>
        //    {
        //        HttpResponseMessage response = null;
        //        var vendors = _vendorsRepository.GetAll().ToList();

        //        IEnumerable<VendorViewModel> vendorsVM = Mapper.Map<IEnumerable<Vendor>, IEnumerable<VendorViewModel>>(vendors);

        //        response = request.CreateResponse<IEnumerable<VendorViewModel>>(HttpStatusCode.OK, vendorsVM);

        //        return response;
        //    });
        //}

       // [AllowAnonymous]
        [Route("latest/{filter?}")]
        public HttpResponseMessage Get(HttpRequestMessage request, string filter = null)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (!string.IsNullOrEmpty(filter))
                {

                     var existingUserDb = _userRepository.GetSingleByUsername(filter);
                     if (existingUserDb != null)
                     {
                         var restaurantDb = _restaurantRepository.AllIncluding().Where(r => r.UserRestaurants.Any(ur => ur.User.ID == existingUserDb.ID)).AsQueryable();
                         IEnumerable<RestaurantViewModel> restaurantVm = Mapper.Map<IEnumerable<Restaurant>, IEnumerable<RestaurantViewModel>>(restaurantDb);

                         if (restaurantVm.Count() > 0)
                         {

                             foreach (var restaurantdetail in restaurantVm)
                             {
                                    var vendors = _vendorsRepository.GetAll().Where(v => v.RestaurantId == restaurantdetail.ID)
                                   .OrderByDescending(it => it.CreatedDate).ToList();
                                    IEnumerable<VendorViewModel> vendorsVM = Mapper.Map<IEnumerable<Vendor>, IEnumerable<VendorViewModel>>(vendors);
                                    response = request.CreateResponse<IEnumerable<VendorViewModel>>(HttpStatusCode.OK, vendorsVM);
                             }
                         }
                     }



                 ;
                }
                else
                {
                    response = request.CreateErrorResponse(HttpStatusCode.Unauthorized, "Invalid User");
                }


               

                return response;
            });
        }

        [Route("vendordetails/{filter?}")]
        public HttpResponseMessage Getdetails(HttpRequestMessage request, int filter)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                VendorViewModel vednusrvm = new VendorViewModel();
                if (filter >0)
                {
                    var inventoryDb = _inventoryRepository.GetSingle(filter);


                    if (inventoryDb != null)
                    {
                        var vedndorrestaurantDb = _vendorsRepository.GetSingle(Convert.ToInt32(inventoryDb.VendorId));
                        
                            // var restaurantDb = _restaurantRepository.AllIncluding().Where(r => r.UserRestaurants.Any(ur => ur.User.ID == existingUserDb.ID)).AsQueryable();
                            //var restaurantDb = _restaurantRepository.GetSingle(userrestaurant.RestaurantId);

                            vednusrvm.ID = vedndorrestaurantDb.ID;
                            vednusrvm.Name = vedndorrestaurantDb.Name.ToString();

                        //     vednusrvm.Email = vedndorrestaurantDb.VendorAddresses.
                        //vednusrvm.AddressDetails = vedndorrestaurantDb.AddressDetails;
                        //vednusrvm.StreetName = vedndorrestaurantDb.StreetName,
                        //vednusrvm.City = vedndorrestaurantDb.City,
                        //vednusrvm.State = vedndorrestaurantDb.State,
                        //vednusrvm.Zip = addressDb.Zip,
                        //vednusrvm.Country = addressDb.Country,
                        //vednusrvm.PrimaryPhone = addressDb.PrimaryPhone,
                        //vednusrvm.CreatedDate = addressDb.CreatedDate.HasValue ? addressDb.CreatedDate : null


                            //response = request.CreateResponse<VendorUserViewModel>(HttpStatusCode.OK, vednusrvm);
                            response = request.CreateResponse<VendorViewModel>(HttpStatusCode.OK, vednusrvm);
                        return response;
                    }
                    else
                    {
                        response = request.CreateErrorResponse(HttpStatusCode.Unauthorized, "Invalid User");
                    }
                }

                else
                {
                    response = request.CreateErrorResponse(HttpStatusCode.Unauthorized, "Invalid User");

                }



                return response;
            });
        }

        //private List<AddressViewModel> GetRestuarantDetail(int restuarantId)
        //{
        //    List<AddressViewModel> listRestaurantAddress = new List<AddressViewModel>();

        //    var restaurantAddressdb = _restaurantAddressRepository.GetAll().Where(r => r.Restaurant.ID == restuarantId).ToList();

        //    if (restaurantAddressdb.Count > 0)
        //    {

        //        foreach (var restaurantAddress in restaurantAddressdb)
        //        {
        //            var addressDb = _addressRepository.GetSingle(restaurantAddress.AddressId);
        //            AddressViewModel listaddressDb = new AddressViewModel()
        //            {

        //                Email = addressDb.Email,
        //                AddressDetails = addressDb.AddressDetails,
        //                StreetName = addressDb.StreetName,
        //                City = addressDb.City,
        //                State = addressDb.State,
        //                Zip = addressDb.Zip,
        //                Country = addressDb.Country,
        //                PrimaryPhone = addressDb.PrimaryPhone,
        //                CreatedDate = addressDb.CreatedDate.HasValue ? addressDb.CreatedDate : null


        //            };


        //            listRestaurantAddress.Add(listaddressDb);
        //        }

        //        //  listRestaurantAddress.Sort((r1, r2) => r2.CreatedDate.CompareTo(r1.CreatedDate));
        //    }

        //    return listRestaurantAddress;
        //}



        [Route("details/{vendorId:int}")]
        public HttpResponseMessage Get(HttpRequestMessage request, int vendorId)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var vendor = _vendorsRepository.GetSingle(vendorId);

                VendorViewModel vendorVM = Mapper.Map<Vendor, VendorViewModel>(vendor);

                
               
                 if (vendor == null )
                 {
                     response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid Vendor ID");
                 }
                 else
                 {

                     //foreach (var vendorAddress in vendor.VendorAddresses)
                     //{
                     //    vendorVM.AddressDetails = vendorAddress.Address.AddressDetails;
                     //    vendorVM.Email = vendorAddress.Address.Email;
                     //    vendorVM.WebsiteURL = vendorAddress.Address.WebsiteURL;
                     //    vendorVM.PrimaryPhone = vendorAddress.Address.PrimaryPhone;
                     //    vendorVM.StreetName = vendorAddress.Address.StreetName;

                     //    vendorVM.City = vendorAddress.Address.City;
                     //    vendorVM.State = vendorAddress.Address.State;
                     //    vendorVM.Country = vendorAddress.Address.Country;
                     //    vendorVM.Zip = vendorAddress.Address.Zip;
                        

                     //    //address.Email = vendorVm.Email;
                     //    //address.WebsiteURL = vendorVm.WebsiteURL;
                     //    //address.PrimaryPhone = vendorVm.PrimaryPhone;
                     //    //address.StreetName = vendorVm.StreetName;
                     //    //address.City = vendorVm.City;
                     //    //address.State = vendorVm.State;
                     //    //address.Country = vendorVm.Country;

                     //    //address.Zip = vendorVm.Zip;
                     //    //address.Status = true;
                     //    ////address.CreatedBy = restaurantVm.UserEmail;
                     //    //address.CreatedDate = DateTime.Now;
                     //}

                     
                 }
                

                response = request.CreateResponse<VendorViewModel>(HttpStatusCode.OK, vendorVM);

                return response;
            });
        }

        //[AllowAnonymous]
        [Route("add")]
        [HttpPost]
        public HttpResponseMessage Register(HttpRequestMessage request, VendorViewModel vendoruser)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                }
                else
                {
                    if (!string.IsNullOrEmpty(vendoruser.loginUserInfo))
                    {
                        var existingUserDb = _userRepository.GetSingleByUsername(vendoruser.loginUserInfo);

                        var restaurantDb = _restaurantRepository.AllIncluding().Where(r => r.UserRestaurants.Any(ur => ur.User.ID == existingUserDb.ID)).AsQueryable();
                        IEnumerable<RestaurantViewModel> restaurantVm = Mapper.Map<IEnumerable<Restaurant>, IEnumerable<RestaurantViewModel>>(restaurantDb);

                        if (restaurantVm.Count() > 0)
                        {
                            foreach (var restaurantdetail in restaurantVm)
                            {
                                var existingVendor = _vendorsRepository.GetSingleByVendorname(vendoruser.Name);

                                if (existingVendor != null && existingVendor.RestaurantId == restaurantdetail.ID)
                                {
                                    ModelState.AddModelError("Invalid Vendor", "Vendor name already exists");
                                    response = request.CreateResponse(HttpStatusCode.BadRequest,
                                    ModelState.Keys.SelectMany(k => ModelState[k].Errors)
                                          .Select(m => m.ErrorMessage).ToArray());
                                }
                                else
                                {
                                    Vendor newvendor = new Vendor();
                                    newvendor.UpdateVendor(vendoruser, restaurantdetail.ID, existingUserDb.ID);
                                    _vendorsRepository.Add(newvendor);
                                    _unitOfWork.Commit();


                                    //Add Address details
                                    Address newaddress = new Address();
                                    VendorAddress newvendorAddress = new VendorAddress();

                                    foreach (var vendorAddress in vendoruser.VendorAddresses)
                                    {

                                        newaddress.UpdateVendorAddress(vendorAddress);
                                        _addressRepository.Add(newaddress);
                                        _unitOfWork.Commit();


                                        newvendorAddress.VendorId = newvendor.ID;
                                        newvendorAddress.AddressId = newaddress.ID;

                                        _vendoraddressRepository.Add(newvendorAddress);


                                        _unitOfWork.Commit();
                                    }

                                    //Add Address details

                                    Contacts newvendorContacts = new Contacts();

                                    if (vendoruser.VendorContacts.Count >0)
                                    {
                                        foreach (var vendorContacts in vendoruser.VendorContacts)
                                        {
                                            if (vendorContacts.Email.ToString().Trim() != "" || vendorContacts.CellPhone.ToString().Trim() != "")
                                            {
                                                newvendorContacts.UpdateVendorContacts(vendorContacts, newvendor.ID, existingUserDb.ID);
                                                _contactsRepository.Add(newvendorContacts);
                                                _unitOfWork.Commit();
                                            }
                                        }

                                    }

                                    

                                   

                                    //response = request.CreateResponse(HttpStatusCode.OK, new { success = true });
                                    // Update view model


                                    vendoruser = Mapper.Map<Vendor, VendorViewModel>(newvendor);
                                    response = request.CreateResponse<VendorViewModel>(HttpStatusCode.Created, vendoruser);

                                }
                            }
                        }


                    }




                    
                    
                }
                return response;
            });
        }

        [MimeMultipart]
        [Route("images/upload")]
        public HttpResponseMessage Post(HttpRequestMessage request, int vendorId)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                var vendorOld = _vendorsRepository.GetSingle(vendorId);
                if (vendorOld == null)
                    response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid Vendor.");
                else
                {
                    var uploadPath = HttpContext.Current.Server.MapPath("~/Content/images/vendors");

                    var multipartFormDataStreamProvider = new UploadMultipartFormProvider(uploadPath);

                    // Read the MIME multipart asynchronously 
                    Request.Content.ReadAsMultipartAsync(multipartFormDataStreamProvider);

                    string _localFileName = multipartFormDataStreamProvider
                        .FileData.Select(multiPartData => multiPartData.LocalFileName).FirstOrDefault();

                    // Create response
                    FileUploadResult fileUploadResult = new FileUploadResult
                    {
                        LocalFilePath = _localFileName,

                        FileName = Path.GetFileName(_localFileName),

                        FileLength = new FileInfo(_localFileName).Length
                    };

                    // update database
                    vendorOld.Image = fileUploadResult.FileName;
                    _vendorsRepository.Edit(vendorOld);
                    _unitOfWork.Commit();

                    response = request.CreateResponse(HttpStatusCode.OK, fileUploadResult);
                }

                return response;
            });



        }


        
        [HttpPost]
        [Route("update")]
        public HttpResponseMessage Update(HttpRequestMessage request, VendorViewModel vendoruser)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                }
                else
                {



                    var vendorDb = _vendorsRepository.GetSingle(vendoruser.ID);
                    if (vendorDb == null)
                        response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid Vendor Details.");
                    else
                    {


                        vendorDb.UpdateVendorEdit(vendoruser);
                        _vendorsRepository.Edit(vendorDb);
                        _unitOfWork.Commit();

                        if (vendoruser.VendorAddresses != null)
                        {
                            var vendoraddressDb = _vendoraddressRepository.AllIncluding().Where(vd => vd.VendorId == vendorDb.ID).ToList();

                            foreach (var vendorAddress in vendoraddressDb)
                            {

                                var addressDb = _addressRepository.GetSingle(vendorAddress.AddressId);
                                foreach (var newvendorAddress in vendoruser.VendorAddresses)
                                {
                                    // addressDb.UpdateVendorAddress(vendoruser);
                                    addressDb.UpdateVendorAddress(newvendorAddress);
                                    _addressRepository.Edit(addressDb);
                                    _unitOfWork.Commit();
                                }                               
                            }
                        }

                        if (vendoruser.VendorContacts != null)
                        {
                            //var vendorcontactsDb = _contactsRepository.AllIncluding().Where(vd => vd.VendorId == vendorDb.ID).ToList();

                            //foreach (var contacts in vendorcontactsDb)
                            //{                              

                                foreach (var newcontacts in vendoruser.VendorContacts)
                                {
                                    if (newcontacts.ID == 0)
                                    {
                                        Contacts newvendorContacts = new Contacts();
                                        if (newcontacts.Email.ToString().Trim() != "" || newcontacts.CellPhone.ToString().Trim() != "")
                                        {
                                            newvendorContacts.UpdateVendorContacts(newcontacts, vendorDb.ID, vendorDb.ID);
                                            _contactsRepository.Add(newvendorContacts);
                                            _unitOfWork.Commit();

                                        }
                                        

                                     
                                    }
                                    else
                                    {
                                        var contactsDb = _contactsRepository.GetSingle(newcontacts.ID);
                                        // addressDb.UpdateVendorAddress(vendoruser);
                                        if (newcontacts.Email.ToString().Trim() != "" || newcontacts.CellPhone.ToString().Trim() != "")
                                        {

                                            contactsDb.UpdateVendorContactsEdit(newcontacts);
                                            _contactsRepository.Edit(contactsDb);
                                            _unitOfWork.Commit();   
                                        }
                                 
                                    }                                   
                                }

                           // }
                        }


                        response = request.CreateResponse<VendorViewModel>(HttpStatusCode.OK, vendoruser);
                    }
                }

                return response;
            });
        }



        [HttpPost]
        [Route("delete")]
        public HttpResponseMessage Delete(HttpRequestMessage request, VendorUserViewModel vendoruserVm)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                var vendorDb = _vendorsRepository.GetSingle(vendoruserVm.ID);

                if (vendorDb == null)
                    response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid vendor.");
                else
                {

                    if (vendorDb.Name.ToLower().ToString() == vendoruserVm.Name.ToLower().ToString())
                    {
                        _vendorsRepository.Delete(vendorDb);
                        _unitOfWork.Commit();
                        response = request.CreateResponse<VendorUserViewModel>(HttpStatusCode.OK, vendoruserVm);

                        
                    }
                    else
                    {
                        response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid vendor.");

                    }

                    

                }


                return response;
            });
        }

     
        [Route("contactsdelete/{vendorContactsID:int=0}/{vendorID:int=0}/{vendorName?}/")]
        public HttpResponseMessage Get(HttpRequestMessage request, int vendorContactsID=0, int vendorID=0, string vendorName = null)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                var vendorDb = _vendorsRepository.GetSingle(vendorID);

                if (vendorDb == null)
                    response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid vendor.");
                else
                {
                    if (vendorDb.Name.ToLower().ToString() == vendorName.ToLower().ToString())
                    {
                        if (vendorDb.VendorContacts.Count > 0)
                        {
                            foreach (var deleteContact in vendorDb.VendorContacts.ToList())
                            {                                 
                                if(deleteContact.ID == vendorContactsID)
                                {
                                    var vendorContactsDb = _contactsRepository.GetSingle(deleteContact.ID);
                                    _contactsRepository.Delete(vendorContactsDb);
                                    _unitOfWork.Commit();                                
                                }                               
                            }
                            response = request.CreateResponse(HttpStatusCode.OK, new { success = true });
                        }                       
                    }
                    else
                    {
                        response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid vendor.");
                    }

                }
                
                return response;
            });
        }











    }


     [Authorize(Roles = "Admin")]
     [RoutePrefix("mobileapi/vendors")]

     public class MobileVendorsController : ApiControllerBase
     {
         private readonly IEntityBaseRepository<Vendor> _vendorsRepository;
         private readonly IEntityBaseRepository<Inventory> _inventoryRepository;

         private readonly IEntityBaseRepository<Address> _addressRepository;
         private readonly IEntityBaseRepository<VendorAddress> _vendoraddressRepository;
         private readonly IEntityBaseRepository<User> _userRepository;
         private readonly IEntityBaseRepository<Restaurant> _restaurantRepository;

         private readonly IEntityBaseRepository<Contacts> _contactsRepository;

         public MobileVendorsController(IEntityBaseRepository<Vendor> vendorsRepository,
             IEntityBaseRepository<Address> addressRepository,
             IEntityBaseRepository<VendorAddress> vendoraddressRepository,
             IEntityBaseRepository<Inventory> inventoryRepository,
             IEntityBaseRepository<User> userRepository,
             IEntityBaseRepository<Restaurant> restaurantRepository,
             IEntityBaseRepository<Contacts> contactsRepository,
              IEntityBaseRepository<Error> _errorsRepository, IUnitOfWork _unitOfWork)
             : base(_errorsRepository, _unitOfWork)
         {
             _vendorsRepository = vendorsRepository;
             _addressRepository = addressRepository;
             _vendoraddressRepository = vendoraddressRepository;
             _inventoryRepository = inventoryRepository;
             _userRepository = userRepository;
             _restaurantRepository = restaurantRepository;
             _contactsRepository = contactsRepository;

         }

         //[AllowAnonymous]
         //public HttpResponseMessage Get(HttpRequestMessage request ,string filter)
         //{
         //    return CreateHttpResponse(request, () =>
         //    {
         //        HttpResponseMessage response = null;
         //        var vendors = _vendorsRepository.GetAll().ToList();

         //        IEnumerable<VendorViewModel> vendorsVM = Mapper.Map<IEnumerable<Vendor>, IEnumerable<VendorViewModel>>(vendors);

         //        response = request.CreateResponse<IEnumerable<VendorViewModel>>(HttpStatusCode.OK, vendorsVM);

         //        return response;
         //    });
         //}

         // [AllowAnonymous]

         [AllowAnonymous]
         [Route("latest/{filter?}")]
         public HttpResponseMessage Get(HttpRequestMessage request, string filter = null)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;
                 if (!string.IsNullOrEmpty(filter))
                 {

                     var existingUserDb = _userRepository.GetSingleByUsername(filter);
                     if (existingUserDb != null)
                     {
                         var restaurantDb = _restaurantRepository.AllIncluding().Where(r => r.UserRestaurants.Any(ur => ur.User.ID == existingUserDb.ID)).AsQueryable();
                         IEnumerable<RestaurantViewModel> restaurantVm = Mapper.Map<IEnumerable<Restaurant>, IEnumerable<RestaurantViewModel>>(restaurantDb);

                         if (restaurantVm.Count() > 0)
                         {

                             foreach (var restaurantdetail in restaurantVm)
                             {
                                 var vendors = _vendorsRepository.GetAll().Where(v => v.RestaurantId == restaurantdetail.ID)
                                .OrderByDescending(it => it.CreatedDate).ToList();
                                 IEnumerable<VendorViewModel> vendorsVM = Mapper.Map<IEnumerable<Vendor>, IEnumerable<VendorViewModel>>(vendors);
                                 response = request.CreateResponse<IEnumerable<VendorViewModel>>(HttpStatusCode.OK, vendorsVM);
                             }
                         }
                     }



                     ;
                 }
                 else
                 {
                     response = request.CreateErrorResponse(HttpStatusCode.Unauthorized, "Invalid User");
                 }




                 return response;
             });
         }


         [AllowAnonymous]
         [Route("vendordetails/{filter?}")]
         public HttpResponseMessage Getdetails(HttpRequestMessage request, int filter)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;
                 VendorViewModel vednusrvm = new VendorViewModel();
                 if (filter > 0)
                 {
                     var inventoryDb = _inventoryRepository.GetSingle(filter);


                     if (inventoryDb != null)
                     {
                         var vedndorrestaurantDb = _vendorsRepository.GetSingle(Convert.ToInt32(inventoryDb.VendorId));

                         // var restaurantDb = _restaurantRepository.AllIncluding().Where(r => r.UserRestaurants.Any(ur => ur.User.ID == existingUserDb.ID)).AsQueryable();
                         //var restaurantDb = _restaurantRepository.GetSingle(userrestaurant.RestaurantId);

                         vednusrvm.ID = vedndorrestaurantDb.ID;
                         vednusrvm.Name = vedndorrestaurantDb.Name.ToString();

                         //     vednusrvm.Email = vedndorrestaurantDb.VendorAddresses.
                         //vednusrvm.AddressDetails = vedndorrestaurantDb.AddressDetails;
                         //vednusrvm.StreetName = vedndorrestaurantDb.StreetName,
                         //vednusrvm.City = vedndorrestaurantDb.City,
                         //vednusrvm.State = vedndorrestaurantDb.State,
                         //vednusrvm.Zip = addressDb.Zip,
                         //vednusrvm.Country = addressDb.Country,
                         //vednusrvm.PrimaryPhone = addressDb.PrimaryPhone,
                         //vednusrvm.CreatedDate = addressDb.CreatedDate.HasValue ? addressDb.CreatedDate : null


                         //response = request.CreateResponse<VendorUserViewModel>(HttpStatusCode.OK, vednusrvm);
                         response = request.CreateResponse<VendorViewModel>(HttpStatusCode.OK, vednusrvm);
                         return response;
                     }
                     else
                     {
                         response = request.CreateErrorResponse(HttpStatusCode.Unauthorized, "Invalid User");
                     }
                 }

                 else
                 {
                     response = request.CreateErrorResponse(HttpStatusCode.Unauthorized, "Invalid User");

                 }



                 return response;
             });
         }

         //private List<AddressViewModel> GetRestuarantDetail(int restuarantId)
         //{
         //    List<AddressViewModel> listRestaurantAddress = new List<AddressViewModel>();

         //    var restaurantAddressdb = _restaurantAddressRepository.GetAll().Where(r => r.Restaurant.ID == restuarantId).ToList();

         //    if (restaurantAddressdb.Count > 0)
         //    {

         //        foreach (var restaurantAddress in restaurantAddressdb)
         //        {
         //            var addressDb = _addressRepository.GetSingle(restaurantAddress.AddressId);
         //            AddressViewModel listaddressDb = new AddressViewModel()
         //            {

         //                Email = addressDb.Email,
         //                AddressDetails = addressDb.AddressDetails,
         //                StreetName = addressDb.StreetName,
         //                City = addressDb.City,
         //                State = addressDb.State,
         //                Zip = addressDb.Zip,
         //                Country = addressDb.Country,
         //                PrimaryPhone = addressDb.PrimaryPhone,
         //                CreatedDate = addressDb.CreatedDate.HasValue ? addressDb.CreatedDate : null


         //            };


         //            listRestaurantAddress.Add(listaddressDb);
         //        }

         //        //  listRestaurantAddress.Sort((r1, r2) => r2.CreatedDate.CompareTo(r1.CreatedDate));
         //    }

         //    return listRestaurantAddress;
         //}



         [AllowAnonymous]
         [Route("details/{vendorId:int}")]
         public HttpResponseMessage Get(HttpRequestMessage request, int vendorId)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;
                 var vendor = _vendorsRepository.GetSingle(vendorId);

                 VendorViewModel vendorVM = Mapper.Map<Vendor, VendorViewModel>(vendor);



                 if (vendor == null)
                 {
                     response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid Vendor ID");
                 }
                 else
                 {

                     //foreach (var vendorAddress in vendor.VendorAddresses)
                     //{
                     //    vendorVM.AddressDetails = vendorAddress.Address.AddressDetails;
                     //    vendorVM.Email = vendorAddress.Address.Email;
                     //    vendorVM.WebsiteURL = vendorAddress.Address.WebsiteURL;
                     //    vendorVM.PrimaryPhone = vendorAddress.Address.PrimaryPhone;
                     //    vendorVM.StreetName = vendorAddress.Address.StreetName;

                     //    vendorVM.City = vendorAddress.Address.City;
                     //    vendorVM.State = vendorAddress.Address.State;
                     //    vendorVM.Country = vendorAddress.Address.Country;
                     //    vendorVM.Zip = vendorAddress.Address.Zip;


                     //    //address.Email = vendorVm.Email;
                     //    //address.WebsiteURL = vendorVm.WebsiteURL;
                     //    //address.PrimaryPhone = vendorVm.PrimaryPhone;
                     //    //address.StreetName = vendorVm.StreetName;
                     //    //address.City = vendorVm.City;
                     //    //address.State = vendorVm.State;
                     //    //address.Country = vendorVm.Country;

                     //    //address.Zip = vendorVm.Zip;
                     //    //address.Status = true;
                     //    ////address.CreatedBy = restaurantVm.UserEmail;
                     //    //address.CreatedDate = DateTime.Now;
                     //}


                 }


                 response = request.CreateResponse<VendorViewModel>(HttpStatusCode.OK, vendorVM);

                 return response;
             });
         }

        

         [AllowAnonymous]
         [Route("add")]
         [HttpPost]
         public HttpResponseMessage Register(HttpRequestMessage request, VendorViewModel vendoruser)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;

                 if (!ModelState.IsValid)
                 {
                     response = request.CreateResponse(HttpStatusCode.BadRequest, new { success = false });
                 }
                 else
                 {
                     if (!string.IsNullOrEmpty(vendoruser.loginUserInfo))
                     {
                         var existingUserDb = _userRepository.GetSingleByUsername(vendoruser.loginUserInfo);

                         var restaurantDb = _restaurantRepository.AllIncluding().Where(r => r.UserRestaurants.Any(ur => ur.User.ID == existingUserDb.ID)).AsQueryable();
                         IEnumerable<RestaurantViewModel> restaurantVm = Mapper.Map<IEnumerable<Restaurant>, IEnumerable<RestaurantViewModel>>(restaurantDb);

                         if (restaurantVm.Count() > 0)
                         {
                             foreach (var restaurantdetail in restaurantVm)
                             {
                                 var existingVendor = _vendorsRepository.GetSingleByVendorname(vendoruser.Name);

                                 if (existingVendor != null && existingVendor.RestaurantId == restaurantdetail.ID)
                                 {
                                     ModelState.AddModelError("Invalid Vendor", "Vendor name already exists");
                                     response = request.CreateResponse(HttpStatusCode.BadRequest,
                                     ModelState.Keys.SelectMany(k => ModelState[k].Errors)
                                           .Select(m => m.ErrorMessage).ToArray());
                                 }
                                 else
                                 {
                                     Vendor newvendor = new Vendor();
                                     newvendor.UpdateVendor(vendoruser, restaurantdetail.ID, existingUserDb.ID);
                                     _vendorsRepository.Add(newvendor);
                                     _unitOfWork.Commit();


                                     //Add Address details
                                     Address newaddress = new Address();
                                     VendorAddress newvendorAddress = new VendorAddress();

                                     foreach (var vendorAddress in vendoruser.VendorAddresses)
                                     {

                                         newaddress.UpdateVendorAddress(vendorAddress);
                                         _addressRepository.Add(newaddress);
                                         _unitOfWork.Commit();


                                         newvendorAddress.VendorId = newvendor.ID;
                                         newvendorAddress.AddressId = newaddress.ID;

                                         _vendoraddressRepository.Add(newvendorAddress);


                                         _unitOfWork.Commit();
                                     }

                                     //Add Address details

                                     Contacts newvendorContacts = new Contacts();

                                     if (vendoruser.VendorContacts.Count > 0)
                                     {
                                         foreach (var vendorContacts in vendoruser.VendorContacts)
                                         {
                                             if (vendorContacts.Email.ToString().Trim() != "" || vendorContacts.CellPhone.ToString().Trim() != "")
                                             {
                                                 newvendorContacts.UpdateVendorContacts(vendorContacts, newvendor.ID, existingUserDb.ID);
                                                 _contactsRepository.Add(newvendorContacts);
                                                 _unitOfWork.Commit();
                                             }
                                         }

                                     }





                                     //response = request.CreateResponse(HttpStatusCode.OK, new { success = true });
                                     // Update view model


                                     vendoruser = Mapper.Map<Vendor, VendorViewModel>(newvendor);
                                     response = request.CreateResponse<VendorViewModel>(HttpStatusCode.Created, vendoruser);

                                 }
                             }
                         }


                     }






                 }
                 return response;
             });
         }

         [AllowAnonymous]
         [MimeMultipart]
         [Route("images/upload")]
         public HttpResponseMessage Post(HttpRequestMessage request, int vendorId)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;

                 var vendorOld = _vendorsRepository.GetSingle(vendorId);
                 if (vendorOld == null)
                     response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid Vendor.");
                 else
                 {
                     var uploadPath = HttpContext.Current.Server.MapPath("~/Content/images/vendors");

                     var multipartFormDataStreamProvider = new UploadMultipartFormProvider(uploadPath);

                     // Read the MIME multipart asynchronously 
                     Request.Content.ReadAsMultipartAsync(multipartFormDataStreamProvider);

                     string _localFileName = multipartFormDataStreamProvider
                         .FileData.Select(multiPartData => multiPartData.LocalFileName).FirstOrDefault();

                     // Create response
                     FileUploadResult fileUploadResult = new FileUploadResult
                     {
                         LocalFilePath = _localFileName,

                         FileName = Path.GetFileName(_localFileName),

                         FileLength = new FileInfo(_localFileName).Length
                     };

                     // update database
                     vendorOld.Image = fileUploadResult.FileName;
                     _vendorsRepository.Edit(vendorOld);
                     _unitOfWork.Commit();

                     response = request.CreateResponse(HttpStatusCode.OK, fileUploadResult);
                 }

                 return response;
             });



         }



         [AllowAnonymous]
         [HttpPost]
         [Route("update")]
         public HttpResponseMessage Update(HttpRequestMessage request, VendorViewModel vendoruser)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;

                 if (!ModelState.IsValid)
                 {
                     response = request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                 }
                 else
                 {



                     var vendorDb = _vendorsRepository.GetSingle(vendoruser.ID);
                     if (vendorDb == null)
                         response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid Vendor Details.");
                     else
                     {


                         vendorDb.UpdateVendorEdit(vendoruser);
                         _vendorsRepository.Edit(vendorDb);
                         _unitOfWork.Commit();

                         if (vendoruser.VendorAddresses != null)
                         {
                             var vendoraddressDb = _vendoraddressRepository.AllIncluding().Where(vd => vd.VendorId == vendorDb.ID).ToList();

                             foreach (var vendorAddress in vendoraddressDb)
                             {

                                 var addressDb = _addressRepository.GetSingle(vendorAddress.AddressId);
                                 foreach (var newvendorAddress in vendoruser.VendorAddresses)
                                 {
                                     // addressDb.UpdateVendorAddress(vendoruser);
                                     addressDb.UpdateVendorAddress(newvendorAddress);
                                     _addressRepository.Edit(addressDb);
                                     _unitOfWork.Commit();
                                 }
                             }
                         }

                         if (vendoruser.VendorContacts != null)
                         {
                             //var vendorcontactsDb = _contactsRepository.AllIncluding().Where(vd => vd.VendorId == vendorDb.ID).ToList();

                             //foreach (var contacts in vendorcontactsDb)
                             //{                              

                             foreach (var newcontacts in vendoruser.VendorContacts)
                             {
                                 if (newcontacts.ID == 0)
                                 {
                                     Contacts newvendorContacts = new Contacts();
                                     if (newcontacts.Email.ToString().Trim() != "" || newcontacts.CellPhone.ToString().Trim() != "")
                                     {
                                         newvendorContacts.UpdateVendorContacts(newcontacts, vendorDb.ID, vendorDb.ID);
                                         _contactsRepository.Add(newvendorContacts);
                                         _unitOfWork.Commit();

                                     }



                                 }
                                 else
                                 {
                                     var contactsDb = _contactsRepository.GetSingle(newcontacts.ID);
                                     // addressDb.UpdateVendorAddress(vendoruser);
                                     if (newcontacts.Email.ToString().Trim() != "" || newcontacts.CellPhone.ToString().Trim() != "")
                                     {

                                         contactsDb.UpdateVendorContactsEdit(newcontacts);
                                         _contactsRepository.Edit(contactsDb);
                                         _unitOfWork.Commit();
                                     }

                                 }
                             }

                             // }
                         }


                         response = request.CreateResponse<VendorViewModel>(HttpStatusCode.OK, vendoruser);
                     }
                 }

                 return response;
             });
         }


         [AllowAnonymous]
         [HttpPost]
         [Route("delete")]
         public HttpResponseMessage Delete(HttpRequestMessage request, VendorUserViewModel vendoruserVm)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;

                 var vendorDb = _vendorsRepository.GetSingle(vendoruserVm.ID);

                 if (vendorDb == null)
                     response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid vendor.");
                 else
                 {

                     if (vendorDb.Name.ToLower().ToString() == vendoruserVm.Name.ToLower().ToString())
                     {
                         _vendorsRepository.Delete(vendorDb);
                         _unitOfWork.Commit();
                         response = request.CreateResponse<VendorUserViewModel>(HttpStatusCode.OK, vendoruserVm);


                     }
                     else
                     {
                         response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid vendor.");

                     }



                 }


                 return response;
             });
         }

         [AllowAnonymous]
         [Route("contactsdelete/{vendorContactsID:int=0}/{vendorID:int=0}/{vendorName?}/")]
         public HttpResponseMessage Get(HttpRequestMessage request, int vendorContactsID = 0, int vendorID = 0, string vendorName = null)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;

                 var vendorDb = _vendorsRepository.GetSingle(vendorID);

                 if (vendorDb == null)
                     response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid vendor.");
                 else
                 {
                     if (vendorDb.Name.ToLower().ToString() == vendorName.ToLower().ToString())
                     {
                         if (vendorDb.VendorContacts.Count > 0)
                         {
                             foreach (var deleteContact in vendorDb.VendorContacts.ToList())
                             {
                                 if (deleteContact.ID == vendorContactsID)
                                 {
                                     var vendorContactsDb = _contactsRepository.GetSingle(deleteContact.ID);
                                     _contactsRepository.Delete(vendorContactsDb);
                                     _unitOfWork.Commit();
                                 }
                             }
                             response = request.CreateResponse(HttpStatusCode.OK, new { success = true });
                         }
                     }
                     else
                     {
                         response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid vendor.");
                     }

                 }

                 return response;
             });
         }











     }
}
