﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

//-----------------------------//

using AutoMapper;

using EasyChefDemo.Data.Infrastructure;
using EasyChefDemo.Data.Repositories;
using EasyChefDemo.Entities;
using EasyChefDemo.Services.Abstract;
using EasyChefDemo.Services.Utilities;
using EasyChefDemo.Web.Infrastructure.Core;
using EasyChefDemo.Web.Models;
using EasyChefDemo.Data.Extensions;

using EasyChefDemo.Web.Infrastructure.Extensions;


namespace EasyChefDemo.Web.Controllers
{
    //  [Authorize(Roles = "Admin, SuperAdmin")]
    [Authorize(Roles = "Admin")]
    [RoutePrefix("api/Payments")]
    public class SubscriptionsController : ApiControllerBase
    {

        private readonly IEntityBaseRepository<Subscription> _subscriptionRepository;
        private readonly IEntityBaseRepository<SubscriptionPlan> _subscriptionPlanRepository;
        private readonly IEntityBaseRepository<SubscriptionInterval> _subscriptionIntervalRepository;


        private readonly IEntityBaseRepository<User> _userRepository;
        private readonly IEntityBaseRepository<Restaurant> _restaurantRepository;

        public SubscriptionsController(
           IEntityBaseRepository<Error> _errorsRepository, IUnitOfWork _unitOfWork,
             IEntityBaseRepository<Subscription> subscriptionRepository,
             IEntityBaseRepository<SubscriptionPlan> subscriptionPlanRepository,
             IEntityBaseRepository<SubscriptionInterval> subscriptionIntervalRepository,           

            IEntityBaseRepository<User> userRepository,
            IEntityBaseRepository<Restaurant> restaurantRepository
            
            )
            : base(_errorsRepository, _unitOfWork)
        {
           
            _userRepository = userRepository;
            _restaurantRepository = restaurantRepository;

            _subscriptionRepository = subscriptionRepository;
            _subscriptionPlanRepository = subscriptionPlanRepository;
            _subscriptionIntervalRepository = subscriptionIntervalRepository;


         
        }

        //--------------------------------------------------------------------------------------------------
        // SUBSCRIPTION INTERVAL
        //--------------------------------------------------------------------------------------------------


        [HttpPost]
        [Route("add")]
        public HttpResponseMessage Add(HttpRequestMessage request, List<SubscriptionInterval> subscriptionIntervalList)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                }
                else
                {
                    SubscriptionInterval newsubscriptionIntervalItem = new SubscriptionInterval();

                    if (subscriptionIntervalList != null)
                    {
                        foreach (var subscriptionInterval in subscriptionIntervalList)
                        {
                            //newcategorytem.UpdateCategoryItem(category);
                            //_categoriesRepository.Add(newcategorytem);
                            //_unitOfWork.Commit();
                        }
                    }

                    response = request.CreateResponse(HttpStatusCode.OK, new { success = true });
                }

                return response;
            });
        }



        //--------------------------------------------------------------------------------------------------
        // SUBSCRIPTION INTERVAL     - END
        //--------------------------------------------------------------------------------------------------





       
    }
}
