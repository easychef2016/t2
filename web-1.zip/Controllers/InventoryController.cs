﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using AutoMapper;
using EasyChefDemo.Data.Infrastructure;
using EasyChefDemo.Data.Repositories;
using EasyChefDemo.Entities;
using EasyChefDemo.Web.Infrastructure.Core;
using EasyChefDemo.Web.Models;

using EasyChefDemo.Data.Extensions;



using EasyChefDemo.Web.Infrastructure.Extensions;

using System.Text;

using EasyChefDemo.Web.Infrastructure.Filters;



namespace EasyChefDemo.Web.Controllers
{

     [DeflateCompression]
    [Authorize(Roles = "Admin")]
    [RoutePrefix("api/inventories")]
    public class InventoryController : ApiControllerBase
    {
        private readonly IEntityBaseRepository<Inventory> _inventoryRepository;
        private readonly IEntityBaseRepository<InventoryItem> _inventoryItemsRepository;
        private readonly IEntityBaseRepository<ApprovedInventory> _approvedinventoryRepository;
        private readonly IEntityBaseRepository<RestaurantAddress> _restaurantAddressRepository;
        private readonly IEntityBaseRepository<User> _userRepository;
        private readonly IEntityBaseRepository<Restaurant> _restaurantRepository;
        private readonly IEntityBaseRepository<Vendor> _vendorRepository;
        private readonly IEntityBaseRepository<Address> _addressRepository;
        private readonly IEntityBaseRepository<VendorAddress> _vendoraddressRepository;
        public InventoryController(IEntityBaseRepository<Inventory> inventoryRepository,
            IEntityBaseRepository<InventoryItem> inventoryItemsRepository,
            IEntityBaseRepository<ApprovedInventory> approvedinventoryRepository,
            IEntityBaseRepository<User> userRepository,
            IEntityBaseRepository<Restaurant> restaurantRepository,
            IEntityBaseRepository<Vendor> vendorRepository,
            IEntityBaseRepository<RestaurantAddress> restaurantAddressRepository,
            IEntityBaseRepository<Address> addressRepository,
            IEntityBaseRepository<VendorAddress> vendoraddressRepository,
            IEntityBaseRepository<Error> _errorsRepository, IUnitOfWork _unitOfWork


            )
            : base(_errorsRepository, _unitOfWork)
        {

            _inventoryRepository = inventoryRepository;
            _inventoryItemsRepository = inventoryItemsRepository;
            _approvedinventoryRepository = approvedinventoryRepository;
            _userRepository = userRepository;
            _restaurantRepository = restaurantRepository;
            _vendorRepository = vendorRepository;
            _restaurantAddressRepository = restaurantAddressRepository;
            _addressRepository = addressRepository;
            _vendoraddressRepository = vendoraddressRepository;
        }

        [HttpPost]
        [Route("add")]
        public HttpResponseMessage Add(HttpRequestMessage request, InventoryViewModel inventory)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                }
                else
                {
                    if (!string.IsNullOrEmpty(inventory.loginUserInfo))
                    {

                        var existingUserDb = _userRepository.GetSingleByUsername(inventory.loginUserInfo);
                        var restaurantDb = _restaurantRepository.AllIncluding().Where(r => r.UserRestaurants.Any(ur => ur.User.ID == existingUserDb.ID)).AsQueryable();

                        IEnumerable<RestaurantViewModel> restaurantVm = Mapper.Map<IEnumerable<Restaurant>, IEnumerable<RestaurantViewModel>>(restaurantDb);

                        if (restaurantVm.Count() > 0)
                        {
                            foreach (var restaurantdetail in restaurantVm)
                            {

                                Inventory newinventory = new Inventory();
                                newinventory.UpdateInventory(inventory, restaurantdetail.ID);

                                _inventoryRepository.Add(newinventory);
                                _unitOfWork.Commit();

                                // Update view model

                                inventory = Mapper.Map<Inventory, InventoryViewModel>(newinventory);
                                response = request.CreateResponse<InventoryViewModel>(HttpStatusCode.Created, inventory);
                            }
                        }
                    }
                    else
                    {
                        response = request.CreateErrorResponse(HttpStatusCode.Unauthorized, "Invalid User");
                    }




                }

                return response;
            });
        }

        [HttpPost]
        [Route("update")]
        public HttpResponseMessage Update(HttpRequestMessage request, InventorySheetViewModel inventory)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!ModelState.IsValid)
                {
                    response = request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                }
                else
                {
                    var inventoryDb = _inventoryRepository.GetSingle(inventory.ID);

                    if (inventoryDb == null)
                        response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid inventory.");
                    else
                    {


                        ///-----------------------------------------------------//
                        ///
                        var existingVendor = _vendorRepository.GetSingleByVendorname(inventory.Vendor);
                        if (existingVendor != null)
                        {
                            Inventory newinventory = new Inventory();
                            InventoryViewModel inventoryvm = new InventoryViewModel();

                            inventoryvm.VendorId = Convert.ToInt32(existingVendor.ID.ToString());

                            inventoryDb.UpdateInventoryVendor(inventoryvm);

                            _inventoryRepository.Edit(inventoryDb);
                            _unitOfWork.Commit();
                        }

                        ///-----------------------------------------------------//
                        //finding inventory items to remove from current inventory
                        //var inventoryItemsToRemove = inventoryDb.ApprovedInventories
                        //     .Where(r => !inventory.ApprovedInventories.Any(r2 => r2.InventoryItemId == r.InventoryItemId)).ToList();

                        var inventoryItemsToRemove = inventoryDb.ApprovedInventories
                          .Where(r => !inventory.ApprovedInventories.Any(r2 => r2.InventoryItemId == r.InventoryItemId)).ToList();

                        //finding inventory items to add to current inventory
                        var inventoryItemsToToAdd = inventory.ApprovedInventories
                            .Where(r => !inventoryDb.ApprovedInventories.Any(r2 => r2.InventoryItemId == r.InventoryItemId)).ToList();

                        foreach (var inventoryItemToRemove in inventoryItemsToRemove)
                        {
                            inventoryDb.ApprovedInventories.Remove(inventoryItemToRemove);
                        }






                        if (inventory.ApprovedInventories != null)
                        {
                            foreach (var approvedInventory in inventory.ApprovedInventories)
                            {
                                var inventoryItemDb = _inventoryItemsRepository.GetSingle(approvedInventory.InventoryItemId);
                                if (inventoryItemDb == null)
                                    response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid inventoryItem.");
                                else
                                {
                                    // var appInventory = _approvedinventoryRepository.AllIncluding().Where(ai => ai.InventoryItem.ID == approvedInventory.InventoryItemId && ai.Inventory.ID == inventory.ID);

                                    if (approvedInventory.ID == 0)
                                    {

                                        ApprovedInventory newapprovedinventory = new ApprovedInventory();
                                        newapprovedinventory.UpdateApprovedInventory(approvedInventory, inventory.ID);
                                        _approvedinventoryRepository.Add(newapprovedinventory);

                                        _unitOfWork.Commit();

                                    }
                                    else
                                    {
                                        var appInventoryDb = _approvedinventoryRepository.AllIncluding().Where(ai => ai.InventoryItem.ID == approvedInventory.InventoryItemId && ai.Inventory.ID == inventory.ID && ai.ID == approvedInventory.ID);
                                        if (appInventoryDb.Any())
                                        {

                                            var appInventoryedit = _approvedinventoryRepository.GetSingle(approvedInventory.ID);
                                            appInventoryedit.UpdateApprovedInventory(approvedInventory, inventory.ID);

                                            _approvedinventoryRepository.Edit(appInventoryedit);

                                            _unitOfWork.Commit();
                                            // response = request.CreateResponse<InventoryItemViewModel>(HttpStatusCode.OK, inventoryItem);
                                        }
                                        else
                                        {
                                            response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid Approved Inventory.");
                                        }
                                    }



                                    //IEnumerable<ApprovedInventory> appVM = _approvedinventoryRepository.AllIncluding().Where(ai => ai.InventoryItem.ID == approvedInventory.InventoryItemId && ai.Inventory.ID == inventory.ID);
                                    //if (appVM.Any())
                                    //{
                                    //    ApprovedInventory newapprovedinventory = new ApprovedInventory();
                                    //    newapprovedinventory.UpdateApprovedInventory(approvedInventory, inventory.ID);
                                    //    inventoryDb.ApprovedInventories.Remove(newapprovedinventory);
                                    //   // _approvedinventoryRepository.Delete(newapprovedinventory);
                                    //   // _approvedinventoryRepository.Edit(newapprovedinventory);

                                    //    _unitOfWork.Commit();
                                    //}
                                    //else
                                    //{
                                    //    ApprovedInventory newapprovedinventory = new ApprovedInventory();
                                    //    newapprovedinventory.UpdateApprovedInventory(approvedInventory, inventory.ID);
                                    //    _approvedinventoryRepository.Add(newapprovedinventory);

                                    //    _unitOfWork.Commit();
                                    //}
                                }
                            }
                        }

                        //inventoryItemDb.UpdateInventoryItemEdit(inventoryItem);
                        ////movie.Image = movieDb.Image;
                        //_inventoryItemsRepository.Edit(inventoryItemDb);

                        //_unitOfWork.Commit();
                        response = request.CreateResponse<InventorySheetViewModel>(HttpStatusCode.OK, inventory);
                    }
                }

                return response;
            });
        }

        //[Route("details/{id:int}")]
        //public HttpResponseMessage Get(HttpRequestMessage request, int id)
        //{
        //    return CreateHttpResponse(request, () =>
        //    {
        //        HttpResponseMessage response = null;
        //        var inventory = _inventoryRepository.GetSingle(id);

        //        InventoryViewModel inventoryVM = Mapper.Map<Inventory, InventoryViewModel>(inventory);

        //        response = request.CreateResponse<InventoryViewModel>(HttpStatusCode.OK, inventoryVM);

        //        return response;
        //    });
        //}

        [Route("detailsedit/{id:int}")]
        public HttpResponseMessage Get(HttpRequestMessage request, int id)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                var inventory = _inventoryRepository.GetSingle(id);

                InventorySheetViewModel inventoryVM = Mapper.Map<Inventory, InventorySheetViewModel>(inventory);

                response = request.CreateResponse<InventorySheetViewModel>(HttpStatusCode.OK, inventoryVM);

                return response;
            });
        }


        [Route("invoicedetails/{filterUsername?}/{inventoryId:int=0}/")]
        [CacheFilter(TimeDuration = 100)]  
        public HttpResponseMessage Get(HttpRequestMessage request, int inventoryId, string filterUsername = null)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                //var inventory = _inventoryRepository.GetSingle(id);

                if (!string.IsNullOrEmpty(filterUsername))
                {
                    var existingUserDb = _userRepository.GetSingleByUsername(filterUsername);

                    if (existingUserDb != null)
                    {
                        var inventory = _inventoryRepository.AllIncluding(inv => inv.ApprovedInventories).ToList().Where(inv => inv.ID == inventoryId);
                        //var approvedInventory = _approvedinventoryRepository.AllIncluding(appvd => appvd.InventoryItem).ToList().Where(appvd => appvd.InventoryId == inventoryId);
                        var approvedInventory = _approvedinventoryRepository.GetAll().ToList().Where(appvd => appvd.InventoryId == inventoryId);


                        IEnumerable<InventoryInvoiceViewModel> inventoryVM = Mapper.Map<IEnumerable<ApprovedInventory>, IEnumerable<InventoryInvoiceViewModel>>(approvedInventory);
                        response = request.CreateResponse<IEnumerable<InventoryInvoiceViewModel>>(HttpStatusCode.OK, inventoryVM);

                    }
                    else
                    {
                        response = request.CreateErrorResponse(HttpStatusCode.Unauthorized, "Invalid User");
                    }
                }
                else
                {

                }



                return response;

            });
        }

        [Route("sendemail/{id:int}")]
        public HttpResponseMessage SendEmail(HttpRequestMessage request, int id)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;


                //var inventory = _inventoryRepository.AllIncluding(inv => inv.ApprovedInventories).ToList().Where(inv => inv.ID == id);
                var approvedInventory = _approvedinventoryRepository.AllIncluding(appvd => appvd.InventoryItem).ToList().Where(appvd => appvd.InventoryId == id);


                //This fucntion gets all the details
                //Inventory Information
                //-Restaurant Information
                // Approved Inventory details --> Vendor Details  - > Vendor Contacts -> Vedendor Addresses
                var inventory = _inventoryRepository.GetSingle(id);
                InventorySheetViewModel inventoryVM = Mapper.Map<Inventory, InventorySheetViewModel>(inventory);
                //IEnumerable<InventorySheetViewModel> inventoryVM = Mapper.Map<IEnumerable<Inventory>, IEnumerable<InventorySheetViewModel>>(approvedInventory);


                // Collect Restaurant Details             
                RestaurantUserAddressViewModel restusrvm = new RestaurantUserAddressViewModel();
                string RestraurntEmail = "";
                var restaurantAddressdb = _restaurantAddressRepository.GetAll().Where(r => r.Restaurant.ID == inventoryVM.RestaurantId).ToList();
                if (restaurantAddressdb.Count > 0)
                {
                    foreach (var restaurantAddress in restaurantAddressdb)
                    {
                        var addressDb = _addressRepository.GetSingle(restaurantAddress.AddressId);
                        RestraurntEmail = addressDb.Email.ToString();
                    }
                }


                // Collect All Approved Inventory sheet details for email purpose
                List<ApprovedInventoryViewModel> approvedInventoriesListtoSend = new List<ApprovedInventoryViewModel>();
                foreach (var approvedinventory in inventory.ApprovedInventories)
                {
                    //approvedInventoriesListtoSend.Add(approvedinventory);
                    ApprovedInventoryViewModel appve = new ApprovedInventoryViewModel()
                    {

                        InventoryItemName = approvedinventory.InventoryItem.Name,
                        InventoryItemDescription = approvedinventory.InventoryItem.ItemDescription,

                        Quantity = approvedinventory.Quantity,
                        MinOrder = approvedinventory.MinOrder,
                        ParValue = approvedinventory.ParValue,
                        Order = approvedinventory.Order,
                        Price = approvedinventory.Price,
                        InventoryItemUnit = approvedinventory.InventoryItem.Unit.Name,
                        Vendor = approvedinventory.Vendor.Name,
                        VendorId = approvedinventory.Vendor.ID
                    };

                    approvedInventoriesListtoSend.Add(appve);
                }


              


                // The below function added to send a Vendor Email - : group by vendor   - --- START 
                List<ApprovedInventoryViewModel> _lstGroupbyVendorApprovedsheet = new List<ApprovedInventoryViewModel>();
                List<string> _lstvendorEmail = new List<string>();
                List<string> _lstvendorcontacts = new List<string>();

                foreach (var groupVendor in approvedInventoriesListtoSend.GroupBy(x => x.VendorId).ToList())
                {
                    int vendorID = groupVendor.Key;
                    var vendorDb = _vendorRepository.GetSingle(vendorID);
                    var vendorrepositoryDb = _vendorRepository.GetAll().Where(vendorrepository => vendorrepository.ID == vendorID).ToList();

                    IEnumerable<VendorViewModel> vendorVM = Mapper.Map<IEnumerable<Vendor>, IEnumerable<VendorViewModel>>(vendorrepositoryDb);

                    string VendorEmail = "";
                    string VendorContacts = "";

                    if (vendorDb.VendorAddresses != null)
                    {
                        var vendoraddressDb = _vendoraddressRepository.AllIncluding().Where(vd => vd.VendorId == vendorDb.ID).ToList();

                        foreach (var vendorAddress in vendoraddressDb)
                        {
                            VendorEmail = vendorAddress.Address.Email.ToString();
                            VendorContacts = vendorAddress.Address.PrimaryPhone.ToString();
                            _lstvendorEmail.Add(VendorEmail);
                            _lstvendorcontacts.Add(VendorContacts);
                        }
                    }

                    if (vendorDb.VendorContacts.Count > 0 )
                    {


                        foreach (var vendorcontact in vendorDb.VendorContacts)
                        {
                            VendorEmail = vendorcontact.Email.ToString();
                            VendorContacts = vendorcontact.CellPhone.ToString();
                            _lstvendorEmail.Add(VendorEmail);
                            _lstvendorcontacts.Add(VendorContacts);
                        }
                    }

                    //VendorUserViewModel vendorVM = Mapper.Map<Vendor, VendorUserViewModel>(vendorDb);
                   

                    foreach (var vendor in groupVendor)
                    {
                        ApprovedInventoryViewModel appve = new ApprovedInventoryViewModel()
                        {

                            InventoryItemName = vendor.InventoryItemName,
                            InventoryItemDescription = vendor.InventoryItemDescription,

                            Quantity = vendor.Quantity,
                            MinOrder = vendor.MinOrder,
                            ParValue = vendor.ParValue,
                            Order = vendor.Order,
                            Price = vendor.Price,
                            InventoryItemUnit = vendor.InventoryItemUnit,
                            Vendor = vendor.Vendor,
                            VendorId = vendor.VendorId
                        };

                        _lstGroupbyVendorApprovedsheet.Add(appve);
                    }

                    var mailBodyVendor = GenerateVendorInvoice(inventoryVM, _lstGroupbyVendorApprovedsheet);
                    string restaurantname = inventoryVM.Restaurant.ToString();
                  
                    

                    //Clear List Items
                    _lstGroupbyVendorApprovedsheet.Clear();
                    _lstvendorEmail.Clear();
                    _lstvendorcontacts.Clear();


                }

            

                //Restaurant Copy -Email 
                var mailBody = GenerateInvoice(inventoryVM, approvedInventoriesListtoSend);
          

                //Update Inventory Status --- Sent to Vendor

                Inventory newinventory = new Inventory();
                InventoryViewModel inventoryvm = new InventoryViewModel();

                //inventoryvm.VendorId = Convert.ToInt32(existingVendor.ID.ToString());

                inventory.UpdateInventoryVendorStatus(inventoryvm);

                _inventoryRepository.Edit(inventory);
                _unitOfWork.Commit();

                response = request.CreateResponse(HttpStatusCode.OK, new { success = true });
                return response;
            });
        }

        //private HttpResponseMessage CreateHttpResponse(HttpRequestMessage request, Func<HttpResponseMessage> func)
        //{
        //    throw new NotImplementedException();
        //}

        public string GenerateInvoice(InventorySheetViewModel inventorysheetVM, List<ApprovedInventoryViewModel> approvedlist)
        {

            decimal? totalPrice = null;
            StringBuilder invoiceHtml = new StringBuilder();
            //  invoiceHtml.Append("<b>INVOICE : ").Append(inventorysheetVM.ID.ToString()).Append("</b><br />");
            //    invoiceHtml.Append("<b>DATE : </b>").Append(inventorysheetVM.InventoryDate.ToString()).Append("<br />");
            //invoiceHtml.Append("<b>Invoice Amt :</b> $").Append(invoiceToGenerate.Total.ToString("#.00")).Append("<br />");
            //  invoiceHtml.Append("<br /><b>CUSTOMER CONTACT INFO:</b><br />");
            // invoiceHtml.Append("<b>Name : </b>").Append("Mani kandan").Append("<br />");
            // invoiceHtml.Append("<b>Phone : </b>").Append("xxx-xxx-xxxx").Append("<br />");
            //   invoiceHtml.Append("<b>Email : </b>").Append("xxx@xx.com").Append("<br />");
            //   invoiceHtml.Append("<b>Address : </b><br />").Append("xxxx-xxxxx").Append("<br />");

            invoiceHtml.Append("<br /><b>Order Details:</b><br /><table  class=\"table table-bordered\"><thead><tr><th align=\"left\"  style=\"Font-family: Arial, sans-serif;\">Item</th><th>Item Description</th><th>Unit</th><th>Qty</th><th>Unit Price</th><th>Cost of Order</th><th>Vendor/Supplier</th></tr></thead>");
            // InvoiceItem should be a collection property which contains list of invoice lines
            foreach (var approvedinventory in approvedlist)
            {
                if (approvedinventory.Quantity > 0)
                {
                    totalPrice = Convert.ToDecimal(approvedinventory.Quantity.ToString()) * Convert.ToDecimal(approvedinventory.Price.ToString());
                    invoiceHtml.Append("<tbody><tr><td>").Append(approvedinventory.InventoryItemName.ToString()).Append("</td><td>").Append(approvedinventory.InventoryItemDescription.ToString()).Append("</td><td>").Append(approvedinventory.InventoryItemUnit.ToString()).Append("</td><td>").Append(approvedinventory.Quantity.ToString()).Append("</td><td>").Append(approvedinventory.Price.ToString()).Append("</td><td>").Append(totalPrice.ToString()).Append("</td><td>").Append(approvedinventory.Vendor.ToString()).Append("</td></tr></tbody>");
                }
            }
            invoiceHtml.Append("</table>");
            return invoiceHtml.ToString();
        }

        public string GenerateVendorInvoice(InventorySheetViewModel inventorysheetVM, List<ApprovedInventoryViewModel> approvedlist)
        {

            decimal? totalPrice = null;
            StringBuilder invoiceHtml = new StringBuilder();
            //invoiceHtml.Append("<b>Inventory Name : ").Append(inventorysheetVM.Name.ToString()).Append("</b><br />");
            //invoiceHtml.Append("<b>Inventory Create Date : </b>").Append(inventorysheetVM.InventoryDate.ToString()).Append("<br />");

            //invoiceHtml.Append("<br /><b>FROM</b><br />");
            //invoiceHtml.Append("<b>Restaurant  : </b>").Append(inventorysheetVM.Restaurant.ToString()).Append("<br />");


            invoiceHtml.Append("<br /><b>Order Details:</b><br /><table  class=\"table table-bordered\"><thead><tr><th align=\"left\"  style=\"Font-family: Arial, sans-serif;\">Item</th><th>Item Description</th><th>Unit </th><th>Qty</th><th>Unit Price</th><th>Cost of Order</th><th>Vendor/Supplier</th></tr></thead>");
            // InvoiceItem should be a collection property which contains list of invoice lines
            foreach (var approvedinventory in approvedlist)
            {
                if (approvedinventory.Quantity > 0)
                {
                    totalPrice = Convert.ToDecimal(approvedinventory.Quantity.ToString()) * Convert.ToDecimal(approvedinventory.Price.ToString());
                    invoiceHtml.Append("<tbody><tr><td>").Append(approvedinventory.InventoryItemName.ToString()).Append("</td><td>").Append(approvedinventory.InventoryItemDescription.ToString()).Append("</td><td>").Append(approvedinventory.InventoryItemUnit.ToString()).Append("</td><td>").Append(approvedinventory.Quantity.ToString()).Append("</td><td>").Append(approvedinventory.Price.ToString()).Append("</td><td>").Append(totalPrice.ToString()).Append("</td><td>").Append(approvedinventory.Vendor.ToString()).Append("</td></tr></tbody>");
                }
            }
            invoiceHtml.Append("</table>");
            return invoiceHtml.ToString();
        }

        [AllowAnonymous]
        [Route("latest/{filter?}")]
        [CacheFilter(TimeDuration = 100)]  
        public HttpResponseMessage Get(HttpRequestMessage request, string filter = null)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!string.IsNullOrEmpty(filter))
                {
                    var existingUserDb = _userRepository.GetSingleByUsername(filter);

                    if (existingUserDb != null)
                    {
                        var restaurantDb = _restaurantRepository.AllIncluding().Where(r => r.UserRestaurants.Any(ur => ur.User.ID == existingUserDb.ID)).AsQueryable();

                        IEnumerable<RestaurantViewModel> restaurantVm = Mapper.Map<IEnumerable<Restaurant>, IEnumerable<RestaurantViewModel>>(restaurantDb);

                        if (restaurantVm.Count() > 0)
                        {

                            foreach (var restaurantdetail in restaurantVm)
                            {

                                //  var inventories = _inventoryRepository.GetAll().OrderByDescending(it => it.CreatedDate).ToList();
                                var inventories = _inventoryRepository.GetAll().Where(i => i.RestaurantId == restaurantdetail.ID)
                                   .OrderByDescending(it => it.CreatedDate).ToList();
                                IEnumerable<InventoryViewModel> inventoriesVM = Mapper.Map<IEnumerable<Inventory>, IEnumerable<InventoryViewModel>>(inventories);
                                response = request.CreateResponse<IEnumerable<InventoryViewModel>>(HttpStatusCode.OK, inventoriesVM);
                            }
                        }
                    }
                    else
                    {
                        response = request.CreateErrorResponse(HttpStatusCode.Unauthorized, "Invalid User");
                    }





                }

                else
                {

                }


                return response;
            });
        }



        [HttpPost]
        [Route("delete")]
        public HttpResponseMessage Delete(HttpRequestMessage request, InventorySheetViewModel inventory)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                var inventoryDb = _inventoryRepository.GetSingle(inventory.ID);

                if (inventoryDb == null)
                    response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid inventory.");
                else
                {

                    if (inventoryDb.Name.ToLower().ToString() == inventory.Name.ToLower().ToString())
                    {
                        if (inventoryDb.ApprovedInventories.Count > 0)
                        {
                            foreach (var approvedInventory in inventoryDb.ApprovedInventories.ToList())
                            {
                                var approvedinventoryDb = _approvedinventoryRepository.GetSingle(approvedInventory.ID);
                                _approvedinventoryRepository.Delete(approvedinventoryDb);
                                _unitOfWork.Commit();
                            }

                            _inventoryRepository.Delete(inventoryDb);
                            _unitOfWork.Commit();
                            response = request.CreateResponse<InventorySheetViewModel>(HttpStatusCode.OK, inventory);
                        }

                        else
                        {
                            _inventoryRepository.Delete(inventoryDb);
                            _unitOfWork.Commit();
                            response = request.CreateResponse<InventorySheetViewModel>(HttpStatusCode.OK, inventory);
                        }




                    }
                    else
                    {
                        response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid inventorysheet.");

                    }












                }


                return response;
            });
        }



        [HttpGet]
        [Route("dashboard/{filter?}")]
        public HttpResponseMessage GetDashboard(HttpRequestMessage request, string filter = null)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;

                if (!string.IsNullOrEmpty(filter))
                {
                    var existingUserDb = _userRepository.GetSingleByUsername(filter);

                    if (existingUserDb != null)
                    {
                        var restaurantDb = _restaurantRepository.AllIncluding().Where(r => r.UserRestaurants.Any(ur => ur.User.ID == existingUserDb.ID)).AsQueryable();

                        IEnumerable<RestaurantViewModel> restaurantVm = Mapper.Map<IEnumerable<Restaurant>, IEnumerable<RestaurantViewModel>>(restaurantDb);

                        if (restaurantVm.Count() > 0)
                        {

                            foreach (var restaurantdetail in restaurantVm)
                            {

                                //  var inventories = _inventoryRepository.GetAll().OrderByDescending(it => it.CreatedDate).ToList();
                                var inventories = _inventoryRepository.GetAll().Where(i => i.RestaurantId == restaurantdetail.ID && ((i.CreatedDate.Value.Year == DateTime.Now.Year) && (i.CreatedDate.Value.Month == DateTime.Now.Month) && (i.CreatedDate.Value.Day == DateTime.Now.Day)))
                                   .OrderByDescending(it => it.CreatedDate).ToList();

                                var vendordetails = _inventoryRepository.GetAll().Where(i => i.RestaurantId == restaurantdetail.ID && ((i.SenttoVendorDate.Value.Year == DateTime.Now.Year) && (i.SenttoVendorDate.Value.Month == DateTime.Now.Month) && (i.SenttoVendorDate.Value.Day == DateTime.Now.Day)))
                                .OrderByDescending(it => it.CreatedDate).ToList();

                                var inventoriesMonthly = _inventoryRepository.GetAll().Where(i => i.RestaurantId == restaurantdetail.ID && ((i.CreatedDate.Value.Year == DateTime.Now.Year) && (i.CreatedDate.Value.Month == DateTime.Now.Month) ))
                             .OrderByDescending(it => it.CreatedDate).ToList();




                                DashboardViewModel DashboardVM = new DashboardViewModel();
                                DashboardVM.InventorytotalToday = inventories.Count.ToString();
                                DashboardVM.InventorySubmittedToday = vendordetails.Count.ToString();
                                DashboardVM.InventorytotalMonthly = inventoriesMonthly.Count.ToString();

                                response = request.CreateResponse<DashboardViewModel>(HttpStatusCode.Created, DashboardVM);
                            }
                        }
                    }
                    else
                    {
                        response = request.CreateErrorResponse(HttpStatusCode.Unauthorized, "Invalid User");
                    }





                }

                else
                {

                }


                return response;
            });
        }






    }

     [Authorize(Roles = "Admin")]
    [RoutePrefix("mobileapi/inventories")]
     public class MobileInventoryController : ApiControllerBase
     {
         private readonly IEntityBaseRepository<Inventory> _inventoryRepository;
         private readonly IEntityBaseRepository<InventoryItem> _inventoryItemsRepository;
         private readonly IEntityBaseRepository<ApprovedInventory> _approvedinventoryRepository;
         private readonly IEntityBaseRepository<RestaurantAddress> _restaurantAddressRepository;
         private readonly IEntityBaseRepository<User> _userRepository;
         private readonly IEntityBaseRepository<Restaurant> _restaurantRepository;
         private readonly IEntityBaseRepository<Vendor> _vendorRepository;
         private readonly IEntityBaseRepository<Address> _addressRepository;
         private readonly IEntityBaseRepository<VendorAddress> _vendoraddressRepository;
         public MobileInventoryController(IEntityBaseRepository<Inventory> inventoryRepository,
             IEntityBaseRepository<InventoryItem> inventoryItemsRepository,
             IEntityBaseRepository<ApprovedInventory> approvedinventoryRepository,
             IEntityBaseRepository<User> userRepository,
             IEntityBaseRepository<Restaurant> restaurantRepository,
             IEntityBaseRepository<Vendor> vendorRepository,
             IEntityBaseRepository<RestaurantAddress> restaurantAddressRepository,
             IEntityBaseRepository<Address> addressRepository,
             IEntityBaseRepository<VendorAddress> vendoraddressRepository,
             IEntityBaseRepository<Error> _errorsRepository, IUnitOfWork _unitOfWork


             )
             : base(_errorsRepository, _unitOfWork)
         {

             _inventoryRepository = inventoryRepository;
             _inventoryItemsRepository = inventoryItemsRepository;
             _approvedinventoryRepository = approvedinventoryRepository;
             _userRepository = userRepository;
             _restaurantRepository = restaurantRepository;
             _vendorRepository = vendorRepository;
             _restaurantAddressRepository = restaurantAddressRepository;
             _addressRepository = addressRepository;
             _vendoraddressRepository = vendoraddressRepository;
         }


          [AllowAnonymous]
         [HttpPost]
         [Route("add")]
         public HttpResponseMessage Add(HttpRequestMessage request, InventoryViewModel inventory)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;

                 if (!ModelState.IsValid)
                 {
                     response = request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                 }
                 else
                 {
                     if (!string.IsNullOrEmpty(inventory.loginUserInfo))
                     {

                         var existingUserDb = _userRepository.GetSingleByUsername(inventory.loginUserInfo);
                         var restaurantDb = _restaurantRepository.AllIncluding().Where(r => r.UserRestaurants.Any(ur => ur.User.ID == existingUserDb.ID)).AsQueryable();

                         IEnumerable<RestaurantViewModel> restaurantVm = Mapper.Map<IEnumerable<Restaurant>, IEnumerable<RestaurantViewModel>>(restaurantDb);

                         if (restaurantVm.Count() > 0)
                         {
                             foreach (var restaurantdetail in restaurantVm)
                             {

                                 Inventory newinventory = new Inventory();
                                 newinventory.UpdateInventory(inventory, restaurantdetail.ID);

                                 _inventoryRepository.Add(newinventory);
                                 _unitOfWork.Commit();

                                 // Update view model

                                 inventory = Mapper.Map<Inventory, InventoryViewModel>(newinventory);
                                 response = request.CreateResponse<InventoryViewModel>(HttpStatusCode.Created, inventory);
                             }
                         }
                     }
                     else
                     {
                         response = request.CreateErrorResponse(HttpStatusCode.Unauthorized, "Invalid User");
                     }




                 }

                 return response;
             });
         }


          [AllowAnonymous]
         [HttpPost]
         [Route("update")]
         public HttpResponseMessage Update(HttpRequestMessage request, InventorySheetViewModel inventory)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;

                 if (!ModelState.IsValid)
                 {
                     response = request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                 }
                 else
                 {
                     var inventoryDb = _inventoryRepository.GetSingle(inventory.ID);

                     if (inventoryDb == null)
                         response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid inventory.");
                     else
                     {


                         ///-----------------------------------------------------//
                         ///
                         var existingVendor = _vendorRepository.GetSingleByVendorname(inventory.Vendor);
                         if (existingVendor != null)
                         {
                             Inventory newinventory = new Inventory();
                             InventoryViewModel inventoryvm = new InventoryViewModel();

                             inventoryvm.VendorId = Convert.ToInt32(existingVendor.ID.ToString());

                             inventoryDb.UpdateInventoryVendor(inventoryvm);

                             _inventoryRepository.Edit(inventoryDb);
                             _unitOfWork.Commit();
                         }

                         ///-----------------------------------------------------//
                         //finding inventory items to remove from current inventory
                         //var inventoryItemsToRemove = inventoryDb.ApprovedInventories
                         //     .Where(r => !inventory.ApprovedInventories.Any(r2 => r2.InventoryItemId == r.InventoryItemId)).ToList();

                         var inventoryItemsToRemove = inventoryDb.ApprovedInventories
                           .Where(r => !inventory.ApprovedInventories.Any(r2 => r2.InventoryItemId == r.InventoryItemId)).ToList();

                         //finding inventory items to add to current inventory
                         var inventoryItemsToToAdd = inventory.ApprovedInventories
                             .Where(r => !inventoryDb.ApprovedInventories.Any(r2 => r2.InventoryItemId == r.InventoryItemId)).ToList();

                         foreach (var inventoryItemToRemove in inventoryItemsToRemove)
                         {
                             inventoryDb.ApprovedInventories.Remove(inventoryItemToRemove);
                         }






                         if (inventory.ApprovedInventories != null)
                         {
                             foreach (var approvedInventory in inventory.ApprovedInventories)
                             {
                                 var inventoryItemDb = _inventoryItemsRepository.GetSingle(approvedInventory.InventoryItemId);
                                 if (inventoryItemDb == null)
                                     response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid inventoryItem.");
                                 else
                                 {
                                     // var appInventory = _approvedinventoryRepository.AllIncluding().Where(ai => ai.InventoryItem.ID == approvedInventory.InventoryItemId && ai.Inventory.ID == inventory.ID);

                                     if (approvedInventory.ID == 0)
                                     {

                                         ApprovedInventory newapprovedinventory = new ApprovedInventory();
                                         newapprovedinventory.UpdateApprovedInventory(approvedInventory, inventory.ID);
                                         _approvedinventoryRepository.Add(newapprovedinventory);

                                         _unitOfWork.Commit();

                                     }
                                     else
                                     {
                                         var appInventoryDb = _approvedinventoryRepository.AllIncluding().Where(ai => ai.InventoryItem.ID == approvedInventory.InventoryItemId && ai.Inventory.ID == inventory.ID && ai.ID == approvedInventory.ID);
                                         if (appInventoryDb.Any())
                                         {

                                             var appInventoryedit = _approvedinventoryRepository.GetSingle(approvedInventory.ID);
                                             appInventoryedit.UpdateApprovedInventory(approvedInventory, inventory.ID);

                                             _approvedinventoryRepository.Edit(appInventoryedit);

                                             _unitOfWork.Commit();
                                             // response = request.CreateResponse<InventoryItemViewModel>(HttpStatusCode.OK, inventoryItem);
                                         }
                                         else
                                         {
                                             response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid Approved Inventory.");
                                         }
                                     }



                                     //IEnumerable<ApprovedInventory> appVM = _approvedinventoryRepository.AllIncluding().Where(ai => ai.InventoryItem.ID == approvedInventory.InventoryItemId && ai.Inventory.ID == inventory.ID);
                                     //if (appVM.Any())
                                     //{
                                     //    ApprovedInventory newapprovedinventory = new ApprovedInventory();
                                     //    newapprovedinventory.UpdateApprovedInventory(approvedInventory, inventory.ID);
                                     //    inventoryDb.ApprovedInventories.Remove(newapprovedinventory);
                                     //   // _approvedinventoryRepository.Delete(newapprovedinventory);
                                     //   // _approvedinventoryRepository.Edit(newapprovedinventory);

                                     //    _unitOfWork.Commit();
                                     //}
                                     //else
                                     //{
                                     //    ApprovedInventory newapprovedinventory = new ApprovedInventory();
                                     //    newapprovedinventory.UpdateApprovedInventory(approvedInventory, inventory.ID);
                                     //    _approvedinventoryRepository.Add(newapprovedinventory);

                                     //    _unitOfWork.Commit();
                                     //}
                                 }
                             }
                         }

                         //inventoryItemDb.UpdateInventoryItemEdit(inventoryItem);
                         ////movie.Image = movieDb.Image;
                         //_inventoryItemsRepository.Edit(inventoryItemDb);

                         //_unitOfWork.Commit();
                         response = request.CreateResponse<InventorySheetViewModel>(HttpStatusCode.OK, inventory);
                     }
                 }

                 return response;
             });
         }

         //[Route("details/{id:int}")]
         //public HttpResponseMessage Get(HttpRequestMessage request, int id)
         //{
         //    return CreateHttpResponse(request, () =>
         //    {
         //        HttpResponseMessage response = null;
         //        var inventory = _inventoryRepository.GetSingle(id);

         //        InventoryViewModel inventoryVM = Mapper.Map<Inventory, InventoryViewModel>(inventory);

         //        response = request.CreateResponse<InventoryViewModel>(HttpStatusCode.OK, inventoryVM);

         //        return response;
         //    });
         //}


          [AllowAnonymous]
         [Route("detailsedit/{id:int}")]
         public HttpResponseMessage Get(HttpRequestMessage request, int id)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;
                 var inventory = _inventoryRepository.GetSingle(id);

                 InventorySheetViewModel inventoryVM = Mapper.Map<Inventory, InventorySheetViewModel>(inventory);

                 response = request.CreateResponse<InventorySheetViewModel>(HttpStatusCode.OK, inventoryVM);

                 return response;
             });
         }

          [AllowAnonymous]
         [Route("invoicedetails/{filterUsername?}/{inventoryId:int=0}/")]
         [CacheFilter(TimeDuration = 100)]
         public HttpResponseMessage Get(HttpRequestMessage request, int inventoryId, string filterUsername = null)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;
                 //var inventory = _inventoryRepository.GetSingle(id);

                 if (!string.IsNullOrEmpty(filterUsername))
                 {
                     var existingUserDb = _userRepository.GetSingleByUsername(filterUsername);

                     if (existingUserDb != null)
                     {
                         var inventory = _inventoryRepository.AllIncluding(inv => inv.ApprovedInventories).ToList().Where(inv => inv.ID == inventoryId);
                         //var approvedInventory = _approvedinventoryRepository.AllIncluding(appvd => appvd.InventoryItem).ToList().Where(appvd => appvd.InventoryId == inventoryId);
                         var approvedInventory = _approvedinventoryRepository.GetAll().ToList().Where(appvd => appvd.InventoryId == inventoryId);


                         IEnumerable<InventoryInvoiceViewModel> inventoryVM = Mapper.Map<IEnumerable<ApprovedInventory>, IEnumerable<InventoryInvoiceViewModel>>(approvedInventory);
                         response = request.CreateResponse<IEnumerable<InventoryInvoiceViewModel>>(HttpStatusCode.OK, inventoryVM);

                     }
                     else
                     {
                         response = request.CreateErrorResponse(HttpStatusCode.Unauthorized, "Invalid User");
                     }
                 }
                 else
                 {

                 }



                 return response;

             });
         }


         [AllowAnonymous]
         [Route("sendemail/{id:int}")]
         public HttpResponseMessage SendEmail(HttpRequestMessage request, int id)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;


                 //var inventory = _inventoryRepository.AllIncluding(inv => inv.ApprovedInventories).ToList().Where(inv => inv.ID == id);
                 var approvedInventory = _approvedinventoryRepository.AllIncluding(appvd => appvd.InventoryItem).ToList().Where(appvd => appvd.InventoryId == id);


                 //This fucntion gets all the details
                 //Inventory Information
                 //-Restaurant Information
                 // Approved Inventory details --> Vendor Details  - > Vendor Contacts -> Vedendor Addresses
                 var inventory = _inventoryRepository.GetSingle(id);
                 InventorySheetViewModel inventoryVM = Mapper.Map<Inventory, InventorySheetViewModel>(inventory);
                 //IEnumerable<InventorySheetViewModel> inventoryVM = Mapper.Map<IEnumerable<Inventory>, IEnumerable<InventorySheetViewModel>>(approvedInventory);


                 // Collect Restaurant Details             
                 RestaurantUserAddressViewModel restusrvm = new RestaurantUserAddressViewModel();
                 string RestraurntEmail = "";
                 var restaurantAddressdb = _restaurantAddressRepository.GetAll().Where(r => r.Restaurant.ID == inventoryVM.RestaurantId).ToList();
                 if (restaurantAddressdb.Count > 0)
                 {
                     foreach (var restaurantAddress in restaurantAddressdb)
                     {
                         var addressDb = _addressRepository.GetSingle(restaurantAddress.AddressId);
                         RestraurntEmail = addressDb.Email.ToString();
                     }
                 }


                 // Collect All Approved Inventory sheet details for email purpose
                 List<ApprovedInventoryViewModel> approvedInventoriesListtoSend = new List<ApprovedInventoryViewModel>();
                 foreach (var approvedinventory in inventory.ApprovedInventories)
                 {
                     //approvedInventoriesListtoSend.Add(approvedinventory);
                     ApprovedInventoryViewModel appve = new ApprovedInventoryViewModel()
                     {

                         InventoryItemName = approvedinventory.InventoryItem.Name,
                         InventoryItemDescription = approvedinventory.InventoryItem.ItemDescription,

                         Quantity = approvedinventory.Quantity,
                         MinOrder = approvedinventory.MinOrder,
                         ParValue = approvedinventory.ParValue,
                         Order = approvedinventory.Order,
                         Price = approvedinventory.Price,
                         InventoryItemUnit = approvedinventory.InventoryItem.Unit.Name,
                         Vendor = approvedinventory.Vendor.Name,
                         VendorId = approvedinventory.Vendor.ID
                     };

                     approvedInventoriesListtoSend.Add(appve);
                 }


                 // EMailHelper mailHelper = new EMailHelper();
               


                 // The below function added to send a Vendor Email - : group by vendor   - --- START 
                 List<ApprovedInventoryViewModel> _lstGroupbyVendorApprovedsheet = new List<ApprovedInventoryViewModel>();
                 List<string> _lstvendorEmail = new List<string>();
                 List<string> _lstvendorcontacts = new List<string>();

                 foreach (var groupVendor in approvedInventoriesListtoSend.GroupBy(x => x.VendorId).ToList())
                 {
                     int vendorID = groupVendor.Key;
                     var vendorDb = _vendorRepository.GetSingle(vendorID);
                     var vendorrepositoryDb = _vendorRepository.GetAll().Where(vendorrepository => vendorrepository.ID == vendorID).ToList();

                     IEnumerable<VendorViewModel> vendorVM = Mapper.Map<IEnumerable<Vendor>, IEnumerable<VendorViewModel>>(vendorrepositoryDb);

                     string VendorEmail = "";
                     string VendorContacts = "";

                     if (vendorDb.VendorAddresses != null)
                     {
                         var vendoraddressDb = _vendoraddressRepository.AllIncluding().Where(vd => vd.VendorId == vendorDb.ID).ToList();

                         foreach (var vendorAddress in vendoraddressDb)
                         {
                             VendorEmail = vendorAddress.Address.Email.ToString();
                             VendorContacts = vendorAddress.Address.PrimaryPhone.ToString();
                             _lstvendorEmail.Add(VendorEmail);
                             _lstvendorcontacts.Add(VendorContacts);
                         }
                     }

                     if (vendorDb.VendorContacts.Count > 0)
                     {


                         foreach (var vendorcontact in vendorDb.VendorContacts)
                         {
                             VendorEmail = vendorcontact.Email.ToString();
                             VendorContacts = vendorcontact.CellPhone.ToString();
                             _lstvendorEmail.Add(VendorEmail);
                             _lstvendorcontacts.Add(VendorContacts);
                         }
                     }

                     //VendorUserViewModel vendorVM = Mapper.Map<Vendor, VendorUserViewModel>(vendorDb);


                     foreach (var vendor in groupVendor)
                     {
                         ApprovedInventoryViewModel appve = new ApprovedInventoryViewModel()
                         {

                             InventoryItemName = vendor.InventoryItemName,
                             InventoryItemDescription = vendor.InventoryItemDescription,

                             Quantity = vendor.Quantity,
                             MinOrder = vendor.MinOrder,
                             ParValue = vendor.ParValue,
                             Order = vendor.Order,
                             Price = vendor.Price,
                             InventoryItemUnit = vendor.InventoryItemUnit,
                             Vendor = vendor.Vendor,
                             VendorId = vendor.VendorId
                         };

                         _lstGroupbyVendorApprovedsheet.Add(appve);
                     }

                   
                     



                     //Clear List Items
                     _lstGroupbyVendorApprovedsheet.Clear();
                     _lstvendorEmail.Clear();
                     _lstvendorcontacts.Clear();


                 }

                           
               

                 //Update Inventory Status --- Sent to Vendor

                 Inventory newinventory = new Inventory();
                 InventoryViewModel inventoryvm = new InventoryViewModel();

                 //inventoryvm.VendorId = Convert.ToInt32(existingVendor.ID.ToString());

                 inventory.UpdateInventoryVendorStatus(inventoryvm);

                 _inventoryRepository.Edit(inventory);
                 _unitOfWork.Commit();

                 response = request.CreateResponse(HttpStatusCode.OK, new { success = true });
                 return response;
             });
         }

        

         [AllowAnonymous]
         [Route("latest/{filter?}")]
         [CacheFilter(TimeDuration = 100)]
         public HttpResponseMessage Get(HttpRequestMessage request, string filter = null)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;

                 if (!string.IsNullOrEmpty(filter))
                 {
                     var existingUserDb = _userRepository.GetSingleByUsername(filter);

                     if (existingUserDb != null)
                     {
                         var restaurantDb = _restaurantRepository.AllIncluding().Where(r => r.UserRestaurants.Any(ur => ur.User.ID == existingUserDb.ID)).AsQueryable();

                         IEnumerable<RestaurantViewModel> restaurantVm = Mapper.Map<IEnumerable<Restaurant>, IEnumerable<RestaurantViewModel>>(restaurantDb);

                         if (restaurantVm.Count() > 0)
                         {

                             foreach (var restaurantdetail in restaurantVm)
                             {

                                 //  var inventories = _inventoryRepository.GetAll().OrderByDescending(it => it.CreatedDate).ToList();
                                 var inventories = _inventoryRepository.GetAll().Where(i => i.RestaurantId == restaurantdetail.ID)
                                    .OrderByDescending(it => it.CreatedDate).ToList();
                                 IEnumerable<InventoryViewModel> inventoriesVM = Mapper.Map<IEnumerable<Inventory>, IEnumerable<InventoryViewModel>>(inventories);
                                 response = request.CreateResponse<IEnumerable<InventoryViewModel>>(HttpStatusCode.OK, inventoriesVM);
                             }
                         }
                     }
                     else
                     {
                         response = request.CreateErrorResponse(HttpStatusCode.Unauthorized, "Invalid User");
                     }





                 }

                 else
                 {

                 }


                 return response;
             });
         }


          [AllowAnonymous]
         [HttpPost]
         [Route("delete")]
         public HttpResponseMessage Delete(HttpRequestMessage request, InventorySheetViewModel inventory)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;

                 var inventoryDb = _inventoryRepository.GetSingle(inventory.ID);

                 if (inventoryDb == null)
                     response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid inventory.");
                 else
                 {

                     if (inventoryDb.Name.ToLower().ToString() == inventory.Name.ToLower().ToString())
                     {
                         if (inventoryDb.ApprovedInventories.Count > 0)
                         {
                             foreach (var approvedInventory in inventoryDb.ApprovedInventories.ToList())
                             {
                                 var approvedinventoryDb = _approvedinventoryRepository.GetSingle(approvedInventory.ID);
                                 _approvedinventoryRepository.Delete(approvedinventoryDb);
                                 _unitOfWork.Commit();
                             }

                             _inventoryRepository.Delete(inventoryDb);
                             _unitOfWork.Commit();
                             response = request.CreateResponse<InventorySheetViewModel>(HttpStatusCode.OK, inventory);
                         }

                         else
                         {
                             _inventoryRepository.Delete(inventoryDb);
                             _unitOfWork.Commit();
                             response = request.CreateResponse<InventorySheetViewModel>(HttpStatusCode.OK, inventory);
                         }




                     }
                     else
                     {
                         response = request.CreateErrorResponse(HttpStatusCode.NotFound, "Invalid inventorysheet.");

                     }












                 }


                 return response;
             });
         }


          [AllowAnonymous]
         [HttpGet]
         [Route("dashboard/{filter?}")]
         public HttpResponseMessage GetDashboard(HttpRequestMessage request, string filter = null)
         {
             return CreateHttpResponse(request, () =>
             {
                 HttpResponseMessage response = null;

                 if (!string.IsNullOrEmpty(filter))
                 {
                     var existingUserDb = _userRepository.GetSingleByUsername(filter);

                     if (existingUserDb != null)
                     {
                         var restaurantDb = _restaurantRepository.AllIncluding().Where(r => r.UserRestaurants.Any(ur => ur.User.ID == existingUserDb.ID)).AsQueryable();

                         IEnumerable<RestaurantViewModel> restaurantVm = Mapper.Map<IEnumerable<Restaurant>, IEnumerable<RestaurantViewModel>>(restaurantDb);

                         if (restaurantVm.Count() > 0)
                         {

                             foreach (var restaurantdetail in restaurantVm)
                             {

                                 //  var inventories = _inventoryRepository.GetAll().OrderByDescending(it => it.CreatedDate).ToList();
                                 var inventories = _inventoryRepository.GetAll().Where(i => i.RestaurantId == restaurantdetail.ID && ((i.CreatedDate.Value.Year == DateTime.Now.Year) && (i.CreatedDate.Value.Month == DateTime.Now.Month) && (i.CreatedDate.Value.Day == DateTime.Now.Day)))
                                    .OrderByDescending(it => it.CreatedDate).ToList();

                                 var vendordetails = _inventoryRepository.GetAll().Where(i => i.RestaurantId == restaurantdetail.ID && ((i.SenttoVendorDate.Value.Year == DateTime.Now.Year) && (i.SenttoVendorDate.Value.Month == DateTime.Now.Month) && (i.SenttoVendorDate.Value.Day == DateTime.Now.Day)))
                                 .OrderByDescending(it => it.CreatedDate).ToList();

                                 var inventoriesMonthly = _inventoryRepository.GetAll().Where(i => i.RestaurantId == restaurantdetail.ID && ((i.CreatedDate.Value.Year == DateTime.Now.Year) && (i.CreatedDate.Value.Month == DateTime.Now.Month)))
                              .OrderByDescending(it => it.CreatedDate).ToList();




                                 DashboardViewModel DashboardVM = new DashboardViewModel();
                                 DashboardVM.InventorytotalToday = inventories.Count.ToString();
                                 DashboardVM.InventorySubmittedToday = vendordetails.Count.ToString();
                                 DashboardVM.InventorytotalMonthly = inventoriesMonthly.Count.ToString();

                                 response = request.CreateResponse<DashboardViewModel>(HttpStatusCode.Created, DashboardVM);
                             }
                         }
                     }
                     else
                     {
                         response = request.CreateErrorResponse(HttpStatusCode.Unauthorized, "Invalid User");
                     }





                 }

                 else
                 {

                 }


                 return response;
             });
         }






     }
}
