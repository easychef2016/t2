﻿using EasyChefDemo.Data.Infrastructure;
using EasyChefDemo.Data.Repositories;
using EasyChefDemo.Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace EasyChefDemo.Web.Infrastructure.Core
{
   

    public class ApiControllerBaseExtended : ApiController
    {
        protected List<Type> _requiredRepositories;

        protected readonly IDataRepositoryFactory _dataRepositoryFactory;

        protected IEntityBaseRepository<Error> _errorsRepository;

        protected IEntityBaseRepository<Address> _addressesRepository;
        protected IEntityBaseRepository<Category> _categoriesRepository;
        protected IEntityBaseRepository<InventoryItem> _inventoryItemsRepository;
        protected IEntityBaseRepository<IngredientType> _ingredientTypesRepository;
        protected IEntityBaseRepository<InventoryItemRestaurant> _inventoryItemRestaurantsRepository;
        protected IEntityBaseRepository<InventoryItemLocation> _inventoryItemLocationsRepository;
        protected IEntityBaseRepository<Location> _locationsRepository;
      
        protected IEntityBaseRepository<Recipe> _recipiesRepository;
        protected IEntityBaseRepository<RecipeIngredient> _recipeIngredientsRepository;
        protected IEntityBaseRepository<Restaurant> _restaurantsRepository;
        protected IEntityBaseRepository<RestaurantAddress> _restaurantAddressesRepository;


        protected IUnitOfWork _unitOfWork;

        private HttpRequestMessage RequestMessage;

        public ApiControllerBaseExtended(IDataRepositoryFactory dataRepositoryFactory, IUnitOfWork unitOfWork)
        {
            _dataRepositoryFactory = dataRepositoryFactory;
            _unitOfWork = unitOfWork;
        }

        protected HttpResponseMessage CreateHttpResponse(HttpRequestMessage request, List<Type> repos, Func<HttpResponseMessage> function)
        {
            HttpResponseMessage response = null;

            try
            {
                RequestMessage = request;
                InitRepositories(repos);
                response = function.Invoke();
            }
            catch (DbUpdateException ex)
            {
                LogError(ex);
                response = request.CreateResponse(HttpStatusCode.BadRequest, ex.InnerException.Message);
            }
            catch (Exception ex)
            {
                LogError(ex);
                response = request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }

            return response;
        }

        private void InitRepositories(List<Type> entities)
        {
            _errorsRepository = _dataRepositoryFactory.GetDataRepository<Error>(RequestMessage);

            if (entities.Any(e => e.FullName == typeof(Recipe).FullName))
            {
                _recipiesRepository = _dataRepositoryFactory.GetDataRepository<Recipe>(RequestMessage);
            }

            if (entities.Any(e => e.FullName == typeof(InventoryItem).FullName))
            {
                _inventoryItemsRepository = _dataRepositoryFactory.GetDataRepository<InventoryItem>(RequestMessage);
            }

            if (entities.Any(e => e.FullName == typeof(Restaurant).FullName))
            {
                _restaurantsRepository = _dataRepositoryFactory.GetDataRepository<Restaurant>(RequestMessage);
            }

            if (entities.Any(e => e.FullName == typeof(IngredientType).FullName))
            {
                _ingredientTypesRepository = _dataRepositoryFactory.GetDataRepository<IngredientType>(RequestMessage);
            }

            if (entities.Any(e => e.FullName == typeof(RecipeIngredient).FullName))
            {
                _recipeIngredientsRepository = _dataRepositoryFactory.GetDataRepository<RecipeIngredient>(RequestMessage);
            }


            if (entities.Any(e => e.FullName == typeof(Address).FullName))
            {
                _addressesRepository = _dataRepositoryFactory.GetDataRepository<Address>(RequestMessage);
            }

            if (entities.Any(e => e.FullName == typeof(Category).FullName))
            {
                _categoriesRepository = _dataRepositoryFactory.GetDataRepository<Category>(RequestMessage);
            }

            if (entities.Any(e => e.FullName == typeof(InventoryItemRestaurant).FullName))
            {
                _inventoryItemRestaurantsRepository = _dataRepositoryFactory.GetDataRepository<InventoryItemRestaurant>(RequestMessage);
            }
        }

        private void LogError(Exception ex)
        {
            try
            {
                Error _error = new Error()
                {
                    Message = ex.Message,
                    StackTrace = ex.StackTrace,
                    DateCreated = DateTime.Now
                };

                _errorsRepository.Add(_error);
                _unitOfWork.Commit();
            }
            catch { }
        }
    }
}