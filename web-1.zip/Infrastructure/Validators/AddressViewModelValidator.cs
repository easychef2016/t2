﻿using EasyChefDemo.Web.Models;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace EasyChefDemo.Web.Infrastructure.Validators
{
    public class AddressViewModelValidator :AbstractValidator<AddressViewModel>
    {

        public AddressViewModelValidator()
        {
            //RuleFor(address => address.Email).NotEmpty().EmailAddress()
            //    .WithMessage("Enter a valid Email address");

            RuleFor(address => address.PrimaryPhone).NotEmpty().Matches(@"^\d{10}$")
               .Length(10).WithMessage("Mobile phone must have 10 digits");
            
            RuleFor(address => address.AddressDetails).NotEmpty()
              .Length(1, 100).WithMessage("Address Details must be between 1 - 100 characters");
            RuleFor(address => address.StreetName).NotEmpty()
            .Length(1, 100).WithMessage("Street Name must be between 1 - 100 characters");

            RuleFor(address => address.City).NotEmpty()
            .Length(1, 100).WithMessage("City must be between 1 - 100 characters");

        }
    }
}