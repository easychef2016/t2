﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using FluentValidation;

using EasyChefDemo.Web.Models;
namespace EasyChefDemo.Web.Infrastructure.Validators
{
    public class InventorySheetViewModelValidators:AbstractValidator<InventorySheetViewModel>
    {
        public InventorySheetViewModelValidators()
        {

            //RuleFor(inventory => inventory.ID).GreaterThan(0)
            //    .WithMessage("Select a Inventory ");

            
        }
    }
}