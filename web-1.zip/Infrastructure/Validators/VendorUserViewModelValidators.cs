﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using FluentValidation;
using EasyChefDemo.Web.Models;

namespace EasyChefDemo.Web.Infrastructure.Validators
{
    public class VendorUserViewModelValidators: AbstractValidator<VendorUserViewModel>
    {
        public VendorUserViewModelValidators()
        {
            RuleFor(vendoruser => vendoruser.Name).NotEmpty().Length(1, 100)
                .WithMessage("Vendor Name must be between 1 - 100 characters");

            RuleFor(vendoruser => vendoruser.SalesAgent).NotEmpty().Length(1, 100)
                .WithMessage("Sales Agent must be between 1 - 100 characters");

            RuleFor(vendoruser => vendoruser.Description).NotEmpty().Length(1, 100)
                .WithMessage("About Restaurant must be between 1 - 100 characters");


            //Address Details
            RuleFor(vendoruser => vendoruser.Email).NotEmpty().EmailAddress()
              .WithMessage("Invalid email address");

            RuleFor(vendoruser => vendoruser.WebsiteURL).NotEmpty().WithMessage("Enter url.")
                 .Length(4, 30).WithMessage("Length between 4 and 30 chars.")
                 .Matches(@"[a-z\-\d]").WithMessage("Enter valid Website URL.");

            RuleFor(vendoruser => vendoruser.PrimaryPhone).NotEmpty().Length(1, 10)
                .WithMessage("Enter a valid Phone Number");


            RuleFor(vendoruser => vendoruser.AddressDetails).NotEmpty().Length(1, 100)
                .WithMessage("Enter Restaurant Address Details");

            RuleFor(restaurantuser => restaurantuser.StreetName).NotEmpty().Length(1, 100)
                .WithMessage("Enter Restaurant Address Details");

            RuleFor(vendoruser => vendoruser.City).NotEmpty().Length(1, 100)
                .WithMessage("Enter Restaurant Address Details");

            RuleFor(vendoruser => vendoruser.State).NotEmpty().Length(1, 100)
                .WithMessage("Enter Restaurant Address Details");

            RuleFor(vendoruser => vendoruser.Zip).NotEmpty().Length(1, 100)
                .WithMessage("Enter Restaurant zip Details");

            RuleFor(vendoruser => vendoruser.Country).NotEmpty().Length(1, 100)
                .WithMessage("Enter Restaurant Country Details");

           


       
          

        }

       
       
    }
}