﻿using EasyChefDemo.Web.Models;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EasyChefDemo.Web.Infrastructure.Validators
{
    public class InventoryItemViewModelValidator : AbstractValidator<InventoryItemViewModel>
    {

        public InventoryItemViewModelValidator()
        {
            RuleFor(inventoryitem => inventoryitem.Name).NotEmpty().Length(1, 100)
               .WithMessage("Inventory Item Name must be between 1 - 100 characters");

            RuleFor(inventoryitem => inventoryitem.ItemDescription).NotEmpty().Length(1, 100)
           .WithMessage("Product Name must be between 1 - 100 characters");

            RuleFor(inventoryitem => inventoryitem.UnitId).GreaterThan(0)
           .WithMessage("Select a Unit");

            RuleFor(inventoryitem => inventoryitem.Quantity).NotEmpty()
          .WithMessage("Quantity is required ");

            RuleFor(inventoryitem => inventoryitem.Price).NotEmpty()
         .WithMessage("Price is required ");

            RuleFor(inventoryitem => inventoryitem.PriceDate).NotEmpty()
        .WithMessage("Price Date is required ");
            RuleFor(inventoryitem => inventoryitem.VendorId).GreaterThan(0)
            .WithMessage("Select a Vendor");


            RuleFor(inventoryitem => inventoryitem.CategoryId).GreaterThan(0)
                .WithMessage("Select a Category");



        }
    }
}