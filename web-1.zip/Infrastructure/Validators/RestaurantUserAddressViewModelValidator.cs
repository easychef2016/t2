﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


using FluentValidation;
using EasyChefDemo.Web.Models;

namespace EasyChefDemo.Web.Infrastructure.Validators
{
    public class RestaurantUserAddressViewModelValidator : AbstractValidator<RestaurantUserAddressViewModel>
    {
        public RestaurantUserAddressViewModelValidator()
        {
            RuleFor(r => r.Name).NotEmpty()
              .WithMessage("Invalid Name");
        }
    }
}