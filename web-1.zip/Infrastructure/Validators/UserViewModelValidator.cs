﻿using EasyChefDemo.Web.Models;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EasyChefDemo.Web.Infrastructure.Validators
{
    public class UserViewModelValidator : AbstractValidator<UserViewModel>
    {
        public UserViewModelValidator()
        {

            //RuleFor(user => user.Email).NotEmpty().EmailAddress()
            //   .WithMessage("Enter a valid Email address");
        }
    }
}