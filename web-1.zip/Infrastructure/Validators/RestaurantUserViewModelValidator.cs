﻿using FluentValidation;
using EasyChefDemo.Web.Models;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EasyChefDemo.Web.Infrastructure.Validators
{
   
    public class RestaurantUserViewModelValidator : AbstractValidator<RestaurantUserViewModel>
    {
        public RestaurantUserViewModelValidator()
        {
            RuleFor(restaurantuser => restaurantuser.Name).NotEmpty().Length(1, 100)
                .WithMessage("Restaurant Name must be between 1 - 100 characters");

            RuleFor(restaurantuser => restaurantuser.Description).NotEmpty().Length(1, 100)
                .WithMessage("About Restaurant must be between 1 - 100 characters");


            //Address Details
            RuleFor(restaurantuser => restaurantuser.WebsiteURL).NotEmpty().WithMessage("Enter url.")
                 .Length(4, 30).WithMessage("Length between 4 and 30 chars.")
                 .Matches(@"[a-z\-\d]").WithMessage("Enter valid Website URL.");

            RuleFor(restaurantuser => restaurantuser.PrimaryPhone).NotEmpty().Length(1, 10)
                .WithMessage("Enter a valid Phone Number");


            RuleFor(restaurantuser => restaurantuser.AddressDetails).NotEmpty().Length(1, 100)
                .WithMessage("Enter Restaurant Address Details");

            RuleFor(restaurantuser => restaurantuser.StreetName).NotEmpty().Length(1, 100)
                .WithMessage("Enter Restaurant Address Details");

            RuleFor(restaurantuser => restaurantuser.City).NotEmpty().Length(1, 100)
                .WithMessage("Enter Restaurant Address Details");

            RuleFor(restaurantuser => restaurantuser.State).NotEmpty().Length(1, 100)
                .WithMessage("Enter Restaurant Address Details");

            RuleFor(restaurantuser => restaurantuser.Zip).NotEmpty().Length(1, 100)
                .WithMessage("Enter Restaurant zip Details");

            RuleFor(restaurantuser => restaurantuser.Country).NotEmpty().Length(1, 100)
                .WithMessage("Enter Restaurant Country Details");

            //User Details

            //RuleFor(restaurantuser => restaurantuser.Username).NotEmpty().Length(1, 100)
            // .WithMessage("Invalid username");

            RuleFor(restaurantuser => restaurantuser.Password).NotEmpty().Length(1, 100)
             .WithMessage("Invalid Password");
            RuleFor(restaurantuser => restaurantuser.UserEmail).NotEmpty().EmailAddress()
                .WithMessage("Invalid email address");

        }

       
       
    }
}