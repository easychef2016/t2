﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using EasyChefDemo.Web.Models;
using FluentValidation;

namespace EasyChefDemo.Web.Infrastructure.Validators
{
    public class InventoryViewModelValidator: AbstractValidator<InventoryViewModel>
    {

        public InventoryViewModelValidator()
        {
            RuleFor(inventory => inventory.Name).NotEmpty().Length(1, 100)
               .WithMessage("Inventory Name must be between 1 - 100 characters");

            RuleFor(inventory => inventory.InventoryDate).NotEmpty()
           .WithMessage("Inventory Date Must Selected");

            }
    }
}