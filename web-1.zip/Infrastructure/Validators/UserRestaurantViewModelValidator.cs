﻿using EasyChefDemo.Web.Models;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace EasyChefDemo.Web.Infrastructure.Validators
{
    public class UserRestaurantViewModelValidator : AbstractValidator<UserRestaurantViewModel>
    {
        public UserRestaurantViewModelValidator()
        {
          }
    }
}