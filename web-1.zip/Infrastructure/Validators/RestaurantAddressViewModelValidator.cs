﻿using EasyChefDemo.Web.Models;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace EasyChefDemo.Web.Infrastructure.Validators
{
    public class RestaurantAddressViewModelValidator : AbstractValidator<RestaurantAddressViewModel>
    {
        public RestaurantAddressViewModelValidator()
        {
            RuleFor(restaurantAddress => restaurantAddress.RestaurantId).GreaterThan(0)
                .WithMessage("Select a Restaurant ");
            //RuleFor(approvedinventory => approvedinventory.InventoryId).GreaterThan(0)
            //    .WithMessage("Select a Inventory ");

            
        }

    }
}