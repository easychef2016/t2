﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using FluentValidation;

using EasyChefDemo.Web.Models;

namespace EasyChefDemo.Web.Infrastructure.Validators
{
    public class ApprovedInventoryViewModelValidators :AbstractValidator<ApprovedInventoryViewModel>
    {
        public ApprovedInventoryViewModelValidators()
        {
            RuleFor(approvedinventory => approvedinventory.InventoryItemId).GreaterThan(0)
                .WithMessage("Select a Inventory Item");
            //RuleFor(approvedinventory => approvedinventory.InventoryId).GreaterThan(0)
            //    .WithMessage("Select a Inventory ");

            
        }
    }
}